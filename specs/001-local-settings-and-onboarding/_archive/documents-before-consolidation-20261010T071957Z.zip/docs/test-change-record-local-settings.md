# Local Settings 测试变更记录（T195）

日期：2026-10-10；分支：deepcode；源码基线：e89458156d15b10a2a0ae9ac3af5d20ca2dc9229。记录标识：TCR-S1-ENV-CONFIG-001。B0取证UTC见[清单](../specs/001-local-settings-and-onboarding/evidence/s0-b0-manifest.json)（2026-10-10T06:28:30.9817039Z）；本条是实施前计划，不是测试通过回执。

沿用[已有TCR模板](test-change-record-v2.md) §1“必要性 → 变更边界/覆盖计划 → 验证计划 → 实际变更与验证”。本轮仅建立记录，测试源码变更0、测试执行0、数据库操作0、模型调用0。每个后续批次须先追加自己的具体TCR；本条只覆盖T196–T203首批环境、配置和隔离基础，不授权S2–S5测试变更或立即执行S1。

## 1. 必要性、合同与未决条件

只读源码事实：
- backend/app/core/config.py现行Settings通过env_file=".env"取值；普通Python、Windows旧配置入口的来源规则尚不统一。需要证明新合同的显式Test身份和来源优先级，不能靠DEV_MODE或隐式开发.env。
- tests/postgres_helpers.py从get_settings()连接，随机test_ready_* schema和finally删除只限制schema名；没有先证明目标为专属Test库/角色/实例。备份恢复用例还会在该连接服务器创建临时库。现有用例不证明Test不会接触Development/Demo。
- 新环境分层类型、ResourceManifest、修订manifest/active/pending及跨进程配置写入合同尚未实现；新增用例验证可观察状态和副作用，不能复制存储算法作oracle。

已确认：[Spec](../specs/001-local-settings-and-onboarding/spec.md) FR-001–005/014/029–033；[Plan](../specs/001-local-settings-and-onboarding/plan.md) §2/7；[运行合同](../specs/001-local-settings-and-onboarding/contracts/runtime-configuration.md) §1/2/6；[首批任务](../specs/001-local-settings-and-onboarding/tasks.md) T196–T203。
非敏感来源defaults < saved/mounted-config < explicitly-selected nonsecret-dotenv < process-env；非法高优先值报段级错误，不落回低优先值。配置保存、检测、激活分开；DB/文件根变更待重启，失败保留旧active。默认Fake，真实模型须另有授权。

没有新架构待决项。专属Test库/角色/ACL/Redis/目录/端口/卷归属尚为pending，见[资源计划](../specs/001-local-settings-and-onboarding/resource-plan.md)。待决的是资源准备和实际核验；不能把命名、随机schema或过去M0成功当当前目标授权。

## 2. 具体文件、覆盖与旧断言边界

下列均为未来拟变更，本轮没有创建测试文件或修改测试。实施时先确认实际节点，若文件/合同实质变化，先更新本TCR。

| 任务/拟变更文件 | 新增或必要修改断言 | 框架/边界 |
|---|---|---|
| T196：tests/unit/settings/test_environment.py | 合法缺省development、显式test/demo、非法身份拒绝；DEV_MODE不改变资源身份；安全DTO无secret原文 | pytest unit，隔离tmp_path、合成配置 |
| T197：tests/unit/settings/test_sources.py | 字段优先级与source；显式dotenv；不隐式读取开发.env；非法高优先值不静默回退 | unit/Fake输入，不读取用户密钥 |
| T198：tests/unit/settings/test_cleanup_guard.py；tests/contract/test_environment_contract.py | 实际DB/user/schema与manifest不符、public/其他run、路径越界、Redis全清均在副作用前拒绝；清理失败保留残留事实 | unit故障替身/contract，固定合成身份 |
| T199：tests/postgres_helpers.py；scripts/smoke_m0.ps1；tests/integration/test_backup_restore.py | 仅接入显式Test预检、创建收据、owner核验与本run清理；拒绝错库/角色/实例；保留既有备份与M0断言 | helper和脚本不是“测试通过”；真实集成必须专属Test |
| T200：tests/unit/settings/test_config_persistence.py | 损坏/未来版本、过期修订、双进程争写、故障点、pending_restart；失败不覆盖旧active | unit，tmp_path/子进程仅自有测试根 |
| T201：同T197/T200用例验证实际ConfigService | 服务行为红绿核验，修订与原子manifest唯一有效指针、409冲突、显式恢复 | 不另造镜像实现测试 |
| T202：tests/integration/test_environment_paths.py；现有文件/评测路径相关节点 | config/storage/cache/logs/temp/results/credentials独立；旧库接空storage需预览拒绝自动接纳；路径逃逸拒绝 | 合成文件/独立Test；实际相关原节点在执行记录逐一列出 |
| T203：docs/validation-local-settings.md取证（非测试源码） | 聚焦后按既有要求pytest/mypy/ruff；记录B1差异、skip/失败/哨兵/清理 | 禁用真实模型，资源门禁成立后才运行可能访问DB的命令 |

旧断言保护：
- tests/unit/test_config.py：现有Embedding维度默认和vector schema仍1024、维度不匹配阻断对应业务启动、JWT非法值/脱敏及合法默认语义。新Bootstrap缺配置可启动只更新明确受新启动合同影响的断言；不得删除维度校验或伪造Key。
- tests/contract/test_auth_contract.py、test_auth_api_contract.py及现有授权入口：JWT/RBAC、课程/学生/教师归属、合法/非法凭据和拒绝状态保留。Bootstrap权限不得替代业务JWT。
- tests/unit/workflows/test_workflow_state.py及Workflow/reviews原合同：run身份、轮次、分值、待教师复核不最终化、最终成绩及历史payload兼容保留；客观题零LLM。S1不改这些语义。
- 现有Provider结构化输出/JSON/Pydantic、审核/组卷约束、历史unknown及可空身份/外键：保留，不能用新配置补历史模型事实。
- tests/integration/test_backup_restore.py：同集及授权文件字节一致；未知/不归属材料不虚报完整；活动连接阻断恢复窗口；dump共享锁；复制失败不覆盖旧产物；篡改先拒绝、恢复失败关闭目标、已有目标不覆盖。仅增加隔离目标前置，不放宽这些断言。
- tests/integration/test_m0_smoke.py及smoke脚本：eduagent-test固定项目名和15432/16379/18000、loopback发布、健康/ready/迁移/Redis原验证、只停本次自有进程/资源。旧Windows进程所有权和错误回执保留。

允许改变的旧配置/启动断言必须逐条写明原节点、对应合同和替代覆盖。来源从旧EXE“文件覆盖进程变量”变为统一优先级属于已确认变化；JWT、评分、数据归属、维度、安全失败和清理界限不属于允许变化。S1尚不完成Bootstrap，仅计划后续T216前另立TCR：GET/HEAD缺Origin仍需Token/精确Host，非法Origin拒绝，写入缺Origin拒绝等矩阵。

## 3. 固定场景与预期实现前失败

输入均为合成值/合成目录，绝不复制真实Key作为标记。下表为预期行为，实际实现前执行结果全部not_run。

| case_id | 固定输入/动作 | 期望行为/副作用 |
|---|---|---|
| ENV-01 | 无environment合法缺省；显式test；DEV_MODE真/假；非法staging | 缺省development；test保持test；DEV_MODE不改身份；非法身份拒写 |
| SRC-01 | 同字段defaults A/saved B/显式dotenv C/process-env D | D生效且source为process-env；移除D后C生效；来源逐字段真实 |
| SRC-02 | 高优先URL/端口非法、低优先合法；工作目录有合成.env但未选择 | 返回配置段错误，不回退；未选择.env不作为来源 |
| OWN-01 | manifest为test，实际database/user/实例为其他目标；schema public/其他run | 预检拒绝，创建/写入/删除调用计数均0 |
| OWN-02 | 本run根外路径、父目录、重解析点逃逸；Redis FLUSHALL目标 | 任何清理前拒绝，无越界写入/删除 |
| OWN-03 | 本run已创建schema/files/keys；清理一项注入失败 | 仅清自身；报告精确残留和失败，不扩大删除或伪成功 |
| CFG-01 | 合法active A；候选B；在写revision/切manifest前后各合法故障点 | 保持完整可读状态；未成功提交不覆盖A；错误阶段真实 |
| CFG-02 | 当前revision r；过期r-1写入；第二测试进程争同根 | 冲突响应；第二写服务拒绝；不能只靠进程内锁 |
| CFG-03 | 损坏/未来版本存档；合法可恢复revision | 不自动覆盖或“回退成功”；显式恢复才改变有效指针 |
| CFG-04 | 变更DB/文件根，旧进程有active A，保存pending B | 当前仍使用A；pending标待重启，不跨库或配空storage |
| PATH-01 | 独立dev/demo合成验收副本哨兵；Test run所有子目录 | Test写/清理前后非Test哨兵字节/行/合成凭据引用不变 |
| AI-01 | 父进程存在DEEPSEEK_API_KEY，显式Test/Fake入口 | 不解析真实秘密、不构造外部客户端；外部请求计数0 |

预期缺口：环境/ConfigService入口不存在或现行helper未核验专属Test时，目标行为用例可能不通过。此处仅为静态预期，**没有实际红灯**；ImportError、依赖未装、错节点、资源pending不能当行为红灯。旧危险helper不得为“证明失败”先连接开发库。可用纯Fake边界证明拒绝；入口就绪后再证明动作、事务和实际持久状态。

## 4. B0 / B1 / B2取证

| 层 | 本轮/未来实际状态 | 必填和归因规则 |
|---|---|---|
| B0 | 静态/历史证据已固化；动态not_run | [审计](../specs/001-local-settings-and-onboarding/audit.md)和JSON记录原HEAD/工作区/文件hash/来源/UTC；旧回执只代表原版本 |
| B1 | not_run，T203在T196–T202护栏建立后产生 | 列出已经包含的代码/测试/配置变更、资源实际身份、命令、退出码、失败/skip/warnings、哨兵与清理 |
| B2 | not_run，后续每批回归 | 引用可比B1或最近回执、输入/环境/差异；不能因出现在B1就断言既有失败 |

每层保留source_commit、working_diff/file_manifest、test_revision、脱敏配置/资源身份、UTC和回执来源。没有可比B0动态结果时，失败归因未定，先沿实际调用链定位；可在安全隔离副本定点比较，附加护栏/测试改动必须披露，不能称原样B0。不得回切/清理用户工作区或临时关闭护栏。

## 5. 安全测试目标、资源与停止条件

普通unit/contract仅tmp_path/Fake。实PostgreSQL必须专属Test实例eduagent_test/eduagent_test_runner（或事前证明为等价专属Test目标）、随机schema和实际owner收据；Redis独立，Test固定M0项目端口，不使用当前默认eduagent容器。备份维护角色仅在隔离实例使用；权限、扩展1024和迁移head准备仍pending。

测试入口显式选择test；从测试进程移除继承的真实Provider覆盖并阻断未选择的开发.env，只注入合成秘密。模型/网络默认Fake且计数0；真实调用须独立费用授权。测试不得落到原Windows配置路径；不用原教学数据放哨兵。

停止条件：任何目标/owner/环境身份不符、角色可写dev/demo、资源pending、路径逃逸、异常外部请求、非Test哨兵改变、清理失败或跨进程写保护不成立，停止受影响验证；记录原失败/残留，不能补默认值、换dev库、扩大删除或放宽断言。清理仅manifest本run创建事实，禁全库/schema public删除、FLUSHALL、共享卷down -v及整个用户目录删除。

## 6. 计划命令与实际执行栏

以下为下一轮获准后使用的候选命令，需依赖节点/目标存在及资源门禁，不是本轮运行记录：
- T196/197：pytest tests/unit/settings/test_environment.py tests/unit/settings/test_sources.py
- T198/199：pytest tests/unit/settings/test_cleanup_guard.py tests/contract/test_environment_contract.py；真实M0/backup目标在资源确认后逐节点执行。
- T200/201：pytest tests/unit/settings/test_config_persistence.py
- T202：pytest tests/integration/test_environment_paths.py，并列明直接受影响的原文件/评测节点。
- T203：按项目已定义命令做pytest/mypy/ruff；保存完整命令和环境，不在未护栏工作区直接pytest全量。

| 项目 | 实际状态/证据 |
|---|---|
| 新增/修改测试源码 | 未执行；0文件 |
| 实现前目标节点 | not_run |
| 实现后聚焦测试、pytest/mypy/ruff | not_run |
| PostgreSQL/Redis/schema/临时库/哨兵 | not_run；没有创建或清理 |
| EXE/Docker构建与验收、浏览器 | not_run |
| Fake或真实业务模型请求 | not_run；本轮请求0，真实授权无 |
| 本轮验证 | 仅S0文档、路径、指纹、只读资源观察；见[S0报告](../specs/001-local-settings-and-onboarding/s0-preparation-report.md) |

后续执行时追加真实命令、时间、退出码和回执，不覆写本次not_run形成虚假历史。
