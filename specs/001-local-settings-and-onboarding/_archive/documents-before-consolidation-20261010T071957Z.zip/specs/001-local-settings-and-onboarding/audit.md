# 只读架构审计：EduAgent v3.0

日期：2026-10-10（Asia/Shanghai）。源码基线：`e89458156d15b10a2a0ae9ac3af5d20ca2dc9229`，分支 `deepcode`。开始时仅 Git 已跟踪修改为 `.gitignore`，本轮保护该修改。受限沙箱 Git 初次误报不在工作树；经提权只读命令核实，未修复或改写 Git 配置。

**口径**：Confirmed=源码或指定归档支持；Partial=部分机制存在；Missing=在已检查责任边界缺失；Contradiction=文档/配置声明与实际不一致；Unknown=需要运行或外部证据。本轮不运行 pytest、服务、迁移、付费模型或构建，不读取 .env 密钥值。历史通过只属于历史版本和环境。

上文及A–F为第一轮规划审计快照，历史“全部未勾选”仅指该轮。实际S0完成状态及B0见本文件末尾和[s0-preparation-report.md](s0-preparation-report.md)。

## A. 配置依赖图

```mermaid
flowchart TD
    ENV[进程环境与 .env] --> SETTINGS[AppSettings 强制校验]
    EXE[EXE 外置 env 文件优先] --> ENV
    SETTINGS --> CACHE[get_settings 进程缓存]
    CACHE --> APP[create_app 与 Gradio 构造]
    CACHE --> DB[Engine / Session 缓存]
    CACHE --> FACT[LLM / Embedding / OCR 工厂]
    FACT --> AGENT[出题 / 阅卷 / RAG / Vision]
    APP --> READY[ready 查询 PG SELECT 1 与 Redis PING]
    APP --> RECOVERY[启动时收敛遗留任务]
```

| 编号 | 分类 | 事实、证据与影响 |
|---|---|---|
| A01 | Confirmed | `backend/app/core/config.py:109–118,150–178,327–345`：Pydantic Settings 读取环境与 .env，数据库、Redis、DeepSeek Key/URL/model、JWT 等必填，进程缓存。普通 Python 与 EXE 加载逻辑不同。 |
| A02 | Contradiction | `backend/app/deployment/windows_launcher.py:38–61,411`：外置配置文件覆盖继承环境并送入子进程。不能直接声称当前全入口都是“环境变量最高优先”。 |
| A03 | Partial | `backend/app/core/config.py:290–324` 有安全 public_dict，SecretStr 及隐藏输入错误；这是输出保护，不是加密持久存储。 |
| A04 | Missing | 无统一 SettingsRevision、字段来源、持久 ProviderProfile/TaskBinding 与受控 Probe API。相关配置散落 core/config、工厂与 launcher。 |
| A05 | Partial | `backend/app/core/database.py:51–83`，`ai/llm/factory.py:130`、`embedding/factory.py:193`、`ingestion/ocr/factory.py:37` 有多处全局缓存；仅清一个缓存不足以支持热变更。 |

## B. 启动阻断与权限

| 编号 | 分类 | 事实、证据与影响 |
|---|---|---|
| B01 | Confirmed / HIGH | `backend/main.py:10` 模块导入即 create_app；`core/app.py:95–103` 创建 FastAPI 前加载全部配置，模型密钥缺失时 HTTP 设置入口也不存在。 |
| B02 | Confirmed | `core/app.py:158–214` 的 /health 是存活，/ready 检查配置、PG SELECT 1、Redis；`database.py:102–125` 不检查迁移 head、表完整性或存储目录。 |
| B03 | Partial | `core/app.py:74–85` 在 lifespan 执行中断阅卷、诊断和试卷导入收敛；Bootstrap 不可在业务依赖未就绪时执行这些业务副作用。 |
| B04 | Confirmed | `deployment/windows_launcher.py:345–377` 无配置时能打开 Tkinter 配置窗口；不能把新需求描述成“项目完全没有图形配置”。当前窗口不是浏览器向导，也不提供新就绪分层。 |
| B05 | Missing / HIGH | `core/security.py:58–77,98–128` 认证依赖要求 DB/JWT；AuthenticationMiddleware 只提取 token，不自动保护新公开接口。新设置权限须独立实现。 |
| B06 | Confirmed | `ui/gradio_app.py:1824–1887,1930–1951`：DEV_MODE 快捷登录仍创建账号并签发 JWT，不是无登录 StudentProfile。教师/学生 UI 模式不等于认证替代。 |
| B07 | Partial | `main.py:17` 普通入口 0.0.0.0，`windows_launcher.py:310` Windows loopback，`docker-compose.yml:66` 主机 loopback 发布；不同入口安全边界不可混同。 |

## C. Provider 能力矩阵

| 能力 | 分类 | 实际支持、缺口和证据 |
|---|---|---|
| 默认 LLM | Confirmed / Contradiction | `config.py:121` 接受 openai_compatible；`ai/llm/factory.py:91–98` 只内置 deepseek。通用 Adapter 是新工作。 |
| 结构化输出 | Confirmed | `ai/llm/deepseek.py:157–193` 发 json_object 并本地 JSON/Pydantic 校验，不是服务端严格 json_schema。 |
| AI 出题 | Partial | `ai/agents/question_agent.py:541,699,774` 可注入 settings/provider，已有来源记录，无持久任务级覆盖。 |
| AI 阅卷 | Partial | `services/grading/subjective_grader.py:536,629` 从默认模型创建；可复用注入，不必重写 Workflow。 |
| Reviewer | Contradiction | `ai/agents/reviewer_agent.py:10–15,118–175` 是确定性规则，明确不调用 LLM；模型设置应标不适用。 |
| Embedding | Confirmed / Contradiction | `ai/embedding/factory.py:154–161` 注册 bge/huggingface/local/openai_compatible；`config.py:124` 还接受未注册 deepseek。 |
| Rerank | Partial | `ai/retrieval/reranker.py:459` 的 openai_compatible 是 LLMRerankAdapter 别名，并非独立 /rerank 服务；llm/cross_encoder 可用，none 在 HYBRID_RERANK 不合法。 |
| OCR | Confirmed | `ai/ingestion/ocr/factory.py:10`、`rapidocr.py:20,131`：RapidOCR、PP-OCRv5-mobile、三个本地 ONNX 文件，延迟加载；不是任意 OCR 模型插槽。 |
| Vision | Partial / Unknown | `ai/vision/provider.py:41`、`llm/deepseek.py:71`：独立 vision_model，但同 DeepSeek 端点/Key；白名单与 hostname 声明不等于实际远端可用，本轮未实调。 |
| Probe | Missing | `core/retry_policy.py:101` 只有通用 API/网络/超时/限流分类；没有八类配置诊断合同，工厂构造成功不等于连接成功。 |

### 运行一致性

- **Missing / HIGH**：`ai/workflows/grading_workflow.py:227–247` 的 deps.settings 不进入持久状态；`api/workflow.py:503–524` 恢复用当前配置重建，不能保证跨重启原模型。
- **Missing / HIGH**：`core/app.py:96–101`、`models/document_chunk.py:42–64`、迁移 `0004_document_chunks.py:24` 固定 1024 维；`ai/ingestion/service.py:294–348` 无完整 Embedding 来源持久化。同维度也不能证明模型兼容。
- **Partial / MEDIUM**：`llm/deepseek.py:159,223` 请求可覆盖 model，但 describe 来自默认实例；Rerank `reranker.py:322` 使用覆盖，需记录实际请求模型。
- **Partial / MEDIUM**：BaseLLMProvider 有 aclose，但部分出题/阅卷/Rerank 自建实例缺成对释放（`llm/base.py:76`、`question_agent.py:791`、`subjective_grader.py:629`、`reranker.py:254`）。配置服务引入修订实例时必须明确所有者。

## D. 密钥风险扫描

| 编号 | 分类/级别 | 证据与边界 |
|---|---|---|
| D01 | Contradiction / HIGH | `deployment/configuration_editor.py:234,290` 把表单生成明文 env 并原子落盘；掩码密码框不改变持久风险。 |
| D02 | Contradiction / HIGH | `benchmark/t189/windows_acceptance.py:209–230` 将实际 Key 和含密码数据库 URL 写入 .cache 临时 .env；新验收入口必须调整。未读取实际文件秘密。 |
| D03 | Confirmed | `services/trace_service.py:113–146`、`audit_service.py:20–45` 白名单降低错误内容泄露风险，继续复用。 |
| D04 | Partial / MEDIUM | `benchmark/t160/quality_runner.py:419–465` 会存完整成功响应，可能保存自定义服务回显的秘密；尚无历史泄漏证据，不能表述成已泄漏。 |
| D05 | Missing | 尚无 DPAPI/Credential Manager 或 Docker Secret 凭据引用服务；`pyproject.toml:10` 无 pywin32/keyring/cryptography 直接依赖。 |
| D06 | Unknown | 所有真实密钥的当前有效性、远端端点配置、真实输出是否含密钥均未运行验证；本轮不访问秘密值。 |

## E. 交付、隔离与验证证据

| 编号 | 分类 | 事实与文件 |
|---|---|---|
| E01 | Confirmed | Windows 预检 PG/pgvector/Redis，执行 Alembic 升级、核对版本后允许 worker 服务；只结束自身进程：`windows_launcher.py:154–197,230–255,290–297,424–448`。 |
| E02 | Missing | 数据库和 Redis 安装不在 EXE 内；`packaging/README.md:5,11,21–26`。免手工 .env 不等于免外部依赖。 |
| E03 | Confirmed / Partial | `packaging/EduAgent.spec:8–50` 收 Gradio/迁移资源、onedir；`scripts/build_exe.ps1:13–35` 构建，可选本地模型依赖未全锁定。React 资源收集尚缺。 |
| E04 | Contradiction | `Dockerfile:20–22` 在 HTTP 前构造 Embedding；`docker-compose.yml:45–53` 强制 Demo 云配置且等待依赖健康。新 Bootstrap 需去除该启动阻断，保留业务 /ready 503。 |
| E05 | Partial | `scripts/run_demo.ps1:11–14,36–67` 可指定 env，但默认根 .env；没有统一独立 Demo profile。DEV_MODE 只是开发登录开关。 |
| E06 | Partial / HIGH | `tests/postgres_helpers.py:26–57` 当前 DB 上随机 schema；`tests/integration/test_backup_restore.py:58–80` 同服务器创建临时库。没有强制专属 Test 配置。 |
| E07 | Confirmed | M0 要求 `eduagent-test` 与指定端口：`tests/integration/test_m0_smoke.py:21–45`；`scripts/smoke_m0.ps1:279–310` 有迁移和 readiness 流程。 |
| E08 | Partial | 阅卷 benchmark 默认 selftest：`scripts/run_grading_benchmark.py:917`；检索 --self-test 默认 false：`run_retrieval_benchmark.py:628–632`。当前空参数因旧 UUID 语料在 :681–688 拒绝；显式 manifest 正常路径 :883–905 可真实调用。不能声称默认空命令必污染 public。 |
| E09 | Partial | `setup_benchmark_corpus.py:22` 默认真实 Embedding；`benchmark_corpus.py:177–188,238–244` 随机 schema 和失败清理。旧检索合成分支 :741 的自有种子清理只在 :816–817 正常路径，需收敛到统一 Test 入口。 |
| E10 | Confirmed | `docs/test-change-record-v2.md:7–23,115–117`：每批测试变更先 TCR，代码/测试变化后 pytest、mypy、ruff及相关真实验收；本轮纯规划不执行数据副作用检查。 |

### 历史验证的正确读法

- `docs/validation-report.md:1248`：8d92c44 快照 2662 passed / 0 failed / 1 skipped，不是当前 e894581 原样工作区复验。
- `benchmark/results/v2/t189-optimize-20261007/README.md:7–14`：真实冻结包首次 3 次 9.670/9.032/9.005 秒，后续 5 次 8.865/8.353/8.836/8.307/8.805 秒；已有依赖、云推理 0 次，不证明干净机安装或模型质量。
- 后续配置修复有 `docs/test-change-record-v2.md:990,997–1001` 的 70 项聚焦及新包 8.109 秒单次启动；不能当完整重复性能复验。
- **Contradiction / LOW**：`docs/exe-deployment.md:41` 的“最新”仍是早期未达标数据，和后续最终记录不同。本轮不重写历史，新的验收文档须建立按包/日期索引。
- **Unknown**：当前全量、纯净 Windows、正式发布和恢复激活没有本轮证据。旧报告的 not_run、skip、失败记录均保留。

## F. SpecKit 与实际执行方法

- 安装版本 **1.0.3**：`.specify/init-options.json`、`.specify/integration.json`、`.specify/integrations/speckit.manifest.json`。采用 Codex skills、PowerShell、sequential 编号。
- 活动指针 `.specify/feature.json` 指向 `.specify`；旧 spec/plan/tasks/checklist/research/data-model/contracts/quickstart 均在此。Constitution：`.specify/memory/constitution.md`，版本 1.0.0。
- 正式技能在 `.agents/skills/speckit-{specify,clarify,plan,checklist,tasks,analyze}/SKILL.md`；还存在 constitution、converge、implement、taskstoissues，后两类实施/外发流程本轮不执行。
- 已读取安装技能、核心模板、当前规格/计划/任务相关段落、全部所需文档的有关边界，以及直接源码。根与所查目录未发现额外 AGENTS.md；当前聊天用户提供的通用工程约束有效。
- `.specify/extensions.yml` 不存在，无前后 hooks。通过 Resolve-Template 确认四个模板均来自 `.specify/templates/`，没有猜路径。
- 实际执行了 `check-prerequisites.ps1 -Json -PathsOnly`，进程内设 `SPECIFY_FEATURE_DIRECTORY=specs/001-local-settings-and-onboarding`；该模式 NoPersist，返回新目录。返回 BRANCH 是脚本的 feature 标识，真实 Git 分支仍 deepcode。
- **手工依据技能流程生成**，没有声称调用斜杠命令。setup-plan、setup-tasks、非 PathsOnly prerequisites 会通过 common.ps1 写 feature.json；为遵守“仅规划文档”，不执行这些有状态脚本，不切换旧活动指针。采用已解析模板和等价的显式路径/存在性检查。
- Specify → Clarify（2 问均已答）→ Plan/Research（依技能 Phase 0 委派只读研究）→ Checklist → Tasks → Analyze。Analyze 对产物只读，分析结果作为用户要求的独立报告归档，不自动调用 implement。
- 所有新任务未勾选。旧 T001–T191、T125–T132 和 Constitution 未修改；新编号使用 T192 起，便于跨 Feature 引用不碰撞。

## 保护基线

代码入口与历史运行证据共同支持课程/资料、Hybrid RAG、OCR/人工校正、生成/改编、审核组卷、考试分值、阅卷复核、LangGraph 检查点、分析推荐、文件/备份和交付的存在；不据此声明全部 v2.0 已在当前版本验收。具体保护合同来自旧 contracts/agent-workflow、rag-retrieval、embedding-provider、paper-import、question-source-persistence、exam-assembly、exam-scoring、file-storage、vision-capability、ocr-provider 及新 [plan.md](plan.md) G6。未接生产的 Supervisor、隐藏评测看板及规则 Reviewer 不能被推广成已经具备的功能。


## S0 T192：B0修改前证据固化

取证UTC 2026-10-10T06:28:30.9817039Z；实际Git分支deepcode，HEAD e89458156d15b10a2a0ae9ac3af5d20ca2dc9229。完整[evidence/s0-b0-manifest.json](evidence/s0-b0-manifest.json)保存535个相关已跟踪/保护文件指纹、14份既有Feature文档指纹、私有配置整体完整性指纹及历史回执文件指纹；不保存秘密原文。B0在S0文档修订前采集，未改源码/测试/运行配置。

### 工作区与路径

开始仅已跟踪.gitignore有1行新增：/项目相关技术栈.md；14份Feature文档已存在且未跟踪，不是本轮新增产物。原差异、逐文件列表在manifest.git_before。没有切分支、回滚、提交或推送。
PathsOnly解析的Spec/Plan/Tasks绝对路径均在D:/YJX/MyCode/EduAgent/specs/001-local-settings-and-onboarding/；脚本BRANCH=001-local-settings-and-onboarding是Feature标识，Git分支仍deepcode。
旧指针内容为{"feature_directory":".specify"}，SHA256=3F61275BCCDDFFC1D359A848D1E02A222F24ECA7CFC46DF8D479751F6581F535。已采用quickstart §0.1过程级覆盖及NoPersist检查，未运行会写指针的普通helper。

### 环境与配置来源（脱敏）

读取core/config.py:109–118确认普通Python当前隐式.env；现Windows configure规则仍是外置文件覆盖环境，和未来统一来源不同。仓库.env存在，仅收集字段名与整体完整性指纹；本机Windows C:/Users/10169/AppData/Local/EduAgent/config.env存在，仅取整体指纹。agent进程DEEPSEEK_API_KEY存在，但不能证明应用实际采用或Key有效；没有导入AppSettings/启动应用来猜有效配置。

第一次非提权shell的LOCALAPPDATA被沙箱重定向，该路径未发现文件不能证明真实用户配置不存在；后续只读主机核对已找到真实配置。默认Docker PG/Redis正在运行；未访问DB/Redis，实际库/schema/账号/迁移状态仍unknown。资源计划见[resource-plan.md](resource-plan.md)。

### 历史回执的实际来源和边界

| 来源 | 已归档事实 | 本次边界 |
|---|---|---|
| docs/validation-report.md:1248及t168-bounded汇总引用 | 8d92c44提交快照2662 passed/1 skipped | 历史版本；不是当前HEAD原样复验 |
| benchmark/results/v2/t189-optimize-20261007/README.md、summary.json | 2026-10-07真实Windows包3首次/5后续完整协议；无浏览器渲染、云推理0 | 已有依赖环境；不是本次启动、纯净机或模型在线证据 |
| docs/test-change-record-v2.md §54 | 70项部署聚焦及配置修复包8.109秒单次启动；修复前/初轮失败保留 | 不能代替完整重复性能协议；.cache回执目录已核对存在 |
| benchmark/results/v2/final-gate-retest-20261006/README.md:18/28、summary.json | M0隔离项目迁移/ready/PONG；PG工具15项补验；首次M0失败及重验保留 | 使用旧测试库/卷和合成模型配置；不证明当前Test资源准备或Docker云模型质量 |
| docs/v2.0-exe-acceptance.md | 包/日期索引及后续结果，历史限制仍在 | 与原始README/机器汇总交叉读取，不用“最新”字样代替实际版本 |

以上7份实际回执文件已记录存在性及指纹，不读完整模型响应或重新执行观察者。历史通过/失败/skip均保留，不合并为本轮通过数。B0动态业务测试、DB/Redis操作、Windows运行、Docker构建/启动及模型调用均not_run；既因本轮禁止，也因Test护栏尚未建立。只读路径/源码/回执核对不属于业务测试。

后续B1由T203在护栏与配置修改后采集，B2引用可比B1；无安全B0动态比较就保留归因未定，不拿旧回执冒充修改前运行成功。
