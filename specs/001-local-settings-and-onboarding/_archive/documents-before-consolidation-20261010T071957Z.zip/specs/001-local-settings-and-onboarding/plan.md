# Implementation Plan: Local Settings and Onboarding

**Branch**: `deepcode` | **Date**: 2026-10-10 | **Spec**: [spec.md](spec.md)
**Input**: 独立 Feature；仅规划。用户确认最小 React 外壳及 Docker 外部 Secret 管理。

## Summary

在现有单体中增加数据库外 ConfigService、CredentialStore、ProviderRegistry、ProbeService 与 Bootstrap 生命周期。分开 Setup Ready、Business Prerequisites Ready、Business Ready、逐任务 AI Ready；保留 FastAPI、LangGraph、业务 API、JWT/RBAC 和 Gradio。配置修订及运行快照承担一致性，不以重新初始化系统或重写 Workflow 达成目标。

## Technical Context

- **Language/Version**：沿用 Python >=3.12；新前端 TypeScript。当前 pyproject 只给部分依赖下限，实施用实际兼容锁定结果，不在本轮安装。
- **Primary Dependencies**：FastAPI、Pydantic Settings、SQLAlchemy、Alembic、LangGraph、现有 OpenAI SDK、Gradio；新增前端 React/Vite/Ant Design/React Router，构建期 TS 类型生成。Windows ctypes/DPAPI 无新 Python 密钥框架。
- **Storage**：PostgreSQL16/pgvector(1024)、Redis；配置非敏感 JSON、Windows DPAPI 密文或 Docker Secret 引用。
- **Testing**：既有 pytest unit/contract/integration、mypy、ruff；前端按 TCR 引入 Vitest/Testing Library 与浏览器验收，复用既有浏览器回执方法；不把这些依赖加入本轮仓库。
- **Target Platform**：Windows PC 浏览器、实际 PyInstaller onedir；Docker 开发/验证。Node 只参与构建。
- **Performance Goals**：Probe 上限见 NFR-004；设置不等待外部模型/数据库初始化。记录 Setup/Business 首次耗时，现有 EXE 业务计时目标按旧评测协议保留，不能提前宣称达标。
- **Constraints**：单后端、无新常驻服务，不改考试/评分语义，不删除 User/Role，不做自动索引重建，不把远端兼容标签当能力。
- **Scale/Scope**：单机、单后台配置写入者（进程文件锁拒绝第二写进程），多浏览器通过修订冲突协调；不设计集群配置广播。

## Constitution Check

| 原则 | 研究前 | 设计后/实施门禁 |
|---|---|---|
| I 可运行优先 | 保留三容器 | G5 同时证明设置可达及业务真实 ready；不把 HTTP 存活当核心业务成功 |
| II AI 能力优先 | v1.0 阶段目标已保留 | 本批设置解除 AI 使用障碍；没有全业务 UI 重构；措辞建议见 research |
| III 模型可替换 | 复用 BaseLLMProvider | G3 通用 Adapter 和 Registry；业务不得导入供应商 SDK |
| IV 结构化输出 | 原合同保持 | G3/G6 JSON/Pydantic/Domain DTO；Probe 不豁免实际业务校验 |
| V 可评测 | 历史结果仅追溯 | G7 有配置/数据/Prompt/模型/失败记录，无效果承诺 |

未发现当前需要变更 Constitution 的强制冲突。若后续要改变恢复语义、模型维度或移除身份模型，先独立决策，不在实施时扩大本计划。

## Project Structure

规划产物：spec、audit、research、plan、data-model、contracts/settings-api、contracts/runtime-configuration、quickstart、tasks、roadmap、test-change-plan、checklists、analysis-report。

未来新增模块（目前不存在，不属于本轮改动）：

```text
backend/app/core/environment.py
backend/app/core/bootstrap.py
backend/app/core/settings_security.py
backend/app/services/settings/{config_service,credential_store,windows_credentials,
  mounted_secrets,provider_registry,probe_service,runtime_snapshot,readiness,index_identity}.py
backend/app/schemas/settings.py
backend/app/api/settings.py
backend/app/ai/llm/openai_compatible.py
backend/app/deployment/local_management.py
frontend/src/{app,api,features/onboarding,features/settings,features/diagnostics}/
frontend/src/api/generated.ts
tests/unit/settings/
tests/contract/test_settings_api.py
tests/integration/test_settings_lifecycle.py
```

既有责任边界需未来定点调整：core/config.py/app.py/security.py/database.py/redis.py；各 Provider 工厂；api/workflow.py/grading.py/question_generation.py；ai/workflows/state.py/grading_workflow.py；文件/备份服务；部署 launcher/editor；测试 helper、benchmark 入口、Dockerfile/Compose/PyInstaller。新增数据库元数据仅用于索引身份（KnowledgeBase 的可空 JSONB 登记，见 data-model）；迁移文件名在实施时依实际 head 分配，不能预造与并行开发冲突的 revision。

## 1. 当前与目标架构

当前详见 [audit.md](audit.md)。

```mermaid
flowchart TD
    Launch[Windows / Python / Docker 启动] --> Boot[最小 BootstrapSettings]
    Boot --> Root[根 FastAPI 生命周期]
    Root --> Static[内置 React 静态设置资源]
    Root --> Auth[本机设置授权]
    Auth --> API[Settings API]
    API --> Config[ConfigService 与字段来源]
    Config --> Revisions[(非敏感配置修订)]
    Config --> Secrets[CredentialStore]
    API --> Probe[受控单次 Probe]
    Probe --> Registry[ProviderRegistry / 原适配器]
    Root --> Ready[依赖与迁移诊断]
    Ready -->|Business Prerequisites Ready| Business[装配旧 API / JWT / Gradio]
    Business --> Recovery[调用原恢复钩子一次]
    Recovery --> BusinessReady[Business Ready]
    Business --> Snapshot[运行配置快照]
    Snapshot --> Registry
    Business --> Workflow[原 LangGraph 与业务服务]
    Workflow --> PG[(业务 PG / checkpoints)]
```

不设置第二个业务事实源。ConfigService 管配置，业务服务管课程/成绩，已有 PG 检查点管 Workflow 状态。根应用统一关闭引擎、客户端及管理任务。

## 2. 配置来源与激活

### 2.1 引导身份

启动参数只接受环境、配置根和端口；优先级：显式 CLI 环境 > EDUAGENT_ENVIRONMENT > Windows/Python 默认 development、Docker 默认 demo。test 必须显式；环境/根目录一旦选定不能网页热切换。DEV_MODE 保留为独立且默认 false 的旧快捷登录开关。

配置按三层类型拆分：BootstrapSettings（环境、路径、绑定、静态资源）、BusinessSettings（数据库、Redis、JWT/存储）、Provider 配置。旧 AppSettings 兼容入口经过单一解析器投影；不能向其必填字段填假 Key 让 Bootstrap 通过。旧业务消费者按需要取得配置段，模型只在 AI 调用边界解析。

### 2.2 明确优先级

非敏感字段从低到高：内置合法默认值 < 环境内已保存有效修订 < 显式指定的开发/CI 非敏感 dotenv < 当前进程环境变量。Windows 普通启动不隐式读取仓库或当前目录 .env；Docker 的配置只读挂载在“已保存配置”槽，环境变量照常覆盖。全部入口共用解析器，替代旧 EXE “文件覆盖进程环境”。

秘密不是同一个 merge 字段：Windows 默认解析 DPAPI 引用；Docker 解析允许列表中的 Secret 引用。development/test 可显式启用仅进程生命周期的 secret env 覆盖，用于 CI；不从新 dotenv 持久读取秘密，不将 env 值写入保存文件。UI 返回来源和 secret 状态，不返回覆盖原文。生产者提供字段来源，前端不猜。秘密的process_env覆盖仅在当前进程有效，重启后原运行的该秘密引用为不可用，不自动关联新的同名环境变量。

保存被 env 覆盖的字段必须带 acknowledge_override=true；只更新保存值，响应明确 effective=false，不能声称已生效。非法 env 覆盖阻止该段就绪，不能用旧值/默认值隐瞒。

### 2.3 保存、检测、激活分离

用户保存非敏感 draft → 校验 Schema/能力/路径 → 凭据新修订安全写入 → 显式检测 → 用户激活。未配置 AI 可保留草稿或仅激活业务设置；不能将未测候选标成已验证。

ConfigService 在同文件系统写临时文件、flush 后原子替换修订/manifest，进程文件锁及 expected_revision 防覆盖。新凭据先写，最后切 active 指针；崩溃后孤立密文只登记可清理，不自动删运行引用。写失败保留上一指针并报告原始阶段的安全错误码。配置损坏/未来 schema 不自动改写；进入 Setup，展示最近有效修订供用户显式恢复。备份和回退不会偷偷生效。

激活条件：本地 schema/能力成立；新增、启用或变更的 AI 绑定，其必需能力须引用同候选/Profile/凭据版本且成功后10分钟内的 Probe。禁用/暂不使用的能力无需测试；完全未变的已激活绑定沿用其 activation_validation，不因保存无关业务字段要求重新付费。未经验证的新候选只保存草稿。

10分钟仅是接纳候选的证据新鲜度窗口。激活时将对应能力、不可变绑定/凭据版本、probe_id、tested_at、accepted_at 写入该修订的 activation_validation；它不是10分钟租约。已激活配置、在途快照以及已接纳的 pending_restart 不因 Probe 过期失效；重启只重查本地引用/依赖及配置一致性，不暗中再次付费。变更目标身份或凭据版本须新 Probe，单纯等待、打开页面、轮询、普通重启均不触发模型检测。外部服务后续失败按当前操作真实错误处理，成功检测不承诺持续在线。

### 2.4 热更新表

| 项 | 行为 |
|---|---|
| 草稿、UI向导进度 | 保存即持久，不改变业务运行 |
| LLM/出题/阅卷/LLM重排绑定、阈值和检索策略 | 激活后只影响新运行；旧运行固定快照 |
| Embedding 语义配置 | 先索引兼容检查；本批需受控重启激活，旧索引未知时不直接切换 |
| 本地 OCR/BGE/CrossEncoder 资源 | 检测资源后待重启；无隐式下载 |
| DB/Redis/存储根/JWT/端口/环境 | 待重启；不搬数据，不在原进程换引擎或身份 |

进行中的写任务未排空时不执行重启，30 秒停止等待后保持 pending_restart 并返回 busy，不强杀。暂停 Workflow 可跨重启，但原配置/凭据仍保留。旧无快照非终态运行规则见 research R08；限制只针对影响它的激活。

## 3. 安全凭据和授权

Windows CredentialStore=`put/get/delete/status`，DPAPI CurrentUser，密文目录只授当前用户与系统所需访问，不写安装目录、Git、临时目录或业务备份。所有秘密（Provider Key、DB/Redis 密码、JWT）使用同一边界；URL 拆为非敏感定位与 password_ref，禁在 URL userinfo/query 塞 API Key。

替换生成 credential revision，成功检测和激活后更换引用；旧运行引用继续可用。删除有显式意图，存在 active/pending/nonterminal snapshot 引用返回 409 IN_USE；先完成任务和解除绑定，再删除。已完成历史只保留“曾使用该引用”的元数据，不要求永远保留秘密。显式作废会降低对应 AI Ready，不将保留的失效秘密视作成功。

Docker 外部 Secret 只读，非敏感 profile 通过允许的 secret_id 绑定；不能接受任意本机路径。外部版本必须不可变：轮换挂新名称/版本，旧运行未结束前保留旧挂载；原路径被覆盖或丢失导致原运行 CREDENTIAL_UNAVAILABLE，不改用新值。运行期可用已打开的内存秘密，但重启后无法证明旧版本则阻止恢复。Secret 版本标识用于凭据生命周期，不是源码哈希门禁。

Bootstrap 权限详见 contracts/settings-api。Windows launcher 生成单次32随机字节授权码，管道传给后端；浏览器 fragment 转交 exchange 后立即清地址和内存。5分钟过期且只能消费一次。换取设置 token 存前端内存，闲置10分钟/绝对30分钟过期；刷新/关闭重开按下述持续入口重新授权。 token不入日志、argv、查询串、localStorage/sessionStorage。所有管理API验token+环境+进程+精确Host；安全GET/HEAD缺Origin可接受但不免Token，提供Origin则精确匹配；敏感操作（含exchange）必须合法Origin，按settings-api §1.2拒绝缺失/null/非法值。公开 GET 仅静态资源及粗粒度状态。

Windows持续入口：沿用现有 Launcher 所有者进程，保留一个最小控制窗口，提供“打开设置/重新授权”和“退出”；不恢复旧明文配置编辑器、不新增后台服务。当前 stdin 在 SERVE 后关闭，T221须改为存续于自有worker生命周期的匿名控制管道并提供注册确认；新码只由Launcher生成并通过该受控通道登记，确认后才打开带fragment的设置页，不能写stdout日志。新发码作废该启动器先前未兑换码；已兑换的其他页面会话仍按各自期限到期，支持既定双窗口冲突场景。

授权码过期/已使用、刷新丢失token、关闭浏览器后重开或会话闲置/绝对超时，页面均进入“需要重新授权”，清掉秘密输入并指导用户返回仍在任务栏的Launcher点击上述按钮。新页面换码后GET已保存草稿/进度；未保存输入不承诺恢复，绝不自动重放Probe/迁移。关闭浏览器不停止Launcher；退出Launcher走原自有worker停止规则，正常重启应用后用新实例授权。重复双击EXE若端口/配置根已被占用，提示回到原Launcher，不接管未知实例、不在公共API领码；管道丢失提示受控退出再启动，不能杀死无关进程。

源码启动使用同一 local_management helper及其仍在运行的本机控制入口；Docker 宿主操作员通过受限 exec 管理命令申请一次授权码，在当前终端交互显示，禁止进入容器服务日志；不开放 HTTP 领码端点。Docker 127.0.0.1 发布验证加 token/Origin，不因容器 peer 非 loopback 放弃权限检查。业务 API 继续旧 JWT/RBAC，设置 token 无业务权限；同 OS 用户信任边界明确。

## 4. Provider 与 AI Ready

Registry 唯一生成 UI preset、能力、参数 schema、factory 映射及 Probe 类型，不另维护“支持名称”清单。保留 generate_structured 的原必需参数/返回合同，新能力元数据默认保守 false/unknown，不强制旧 Stub 实现新增抽象方法。

| Binding | 有效解析与依赖 |
|---|---|
| default_llm | 显式选定文本结构化 Profile |
| question_generation / subjective_grading | 可覆盖，否则 default_llm；若实际选 RAG，合并 Embedding/Rerank 就绪 |
| diagnosis / content_validation / paper_extraction | 明确继承 default_llm；当前不再增加三个高级表单 |
| reviewer | rule_based，模型不适用；不得无故调用默认 LLM |
| embedding | 独立配置，绝不自动拿 LLM Key/Model；含索引兼容约束 |
| rerank | llm 可沿用默认 LLM 或绑定专用 Profile；cross_encoder 本地；none 只对不含重排的检索模式合法 |
| vision | 独立 Profile/模型，能力必须支持 image + structured；DeepSeek 原路径保留，通用 Adapter 只在明确实现和 Probe 后可用 |
| ocr | enabled/provider/model/resource_dir；本批只内置现有 RapidOCR 预设，扩展 Provider 不因字段可写自动实现 |

通用 OpenAI-compatible Adapter 最小支持文本 JSON 模式+本地 Pydantic；可声明 json_schema 或 vision，但仅实现其传输/校验合同后列入可选能力。本批不实现所有厂商 SDK或独立云 /rerank。

AI Ready 按任务由有效绑定、真实能力、可用凭据/本地资源、已接纳的 activation_validation 和该任务实际依赖计算。报告 last_probe 与 activation_validation，另列已观察到的 last_runtime_result，不把它们混成一个过期布尔值。新候选未验证为 unverified；已激活且依赖仍满足的绑定，即使 last_probe 超过10分钟仍保持 ready。配置失效、能力不匹配、凭据明确失效或依赖不可用才阻止相关操作；暂时网络失败按当前请求报告，不承诺持续在线、不自动付费重测，后续由用户发起的正常业务请求仍可尝试。OCR disabled 为 not_required；规则 Reviewer 为 ready_rule_based。AI状态不得用于全局Business装配门槛，任务入口按快照检查真实依赖。

## 5. Bootstrap 生命周期与初始化

### 5.1 四层状态和无环关系

| 状态 | 判定条件 | 不包含 |
|---|---|---|
| Setup Ready | 静态资源、最小配置读取/诊断及设置授权服务可运行；配置损坏可被安全报告而无需覆盖原文件 | DB、Redis、业务JWT、任何模型在线 |
| Business Prerequisites Ready | 本进程有效Business配置/JWT引用、PG连通、vector扩展、允许的迁移head及必要表列、Redis、持久目录均通过 | 业务路由是否已装配、恢复钩子结果、AI Probe |
| Business Ready | Business Prerequisites Ready + 旧业务路由/鉴权/Gradio装配成功 + 本进程原恢复钩子启动阶段已完成 | 所有AI可用、已有业务账号、所有旧任务可自动恢复 |
| AI Ready | 按任务的配置、能力、凭据/资源、激活接纳证据和实际依赖；见§4 | 无关任务状态、Probe到期倒计时 |

方向固定为：前置依赖检查 → 装配 → 原恢复阶段 → Business Ready。绝不以Business Ready作为装配输入。尚未装配或任一启动阶段失败时，根设置应用保持运行，业务入口503；不存在通过设置请求临时热挂路由的路径。

### 5.2 启动、初始化、重启和恢复

1. 最小引导段建立根应用与设置资源。业务模块改为条件导入，不能为通过工厂校验填假Key/连接。启动检查有短超时，不等待模型、安装服务或自动执行迁移；检查失败仍完成根应用启动。
2. 在本进程启动阶段读取已接纳配置并检查 Business Prerequisites。通过后仅装配一次原/api、原JWT/RBAC和/gradio；失败记录安全原因并留在Setup。根生命周期明确调用原业务启动/关闭逻辑，不能依赖mount隐式运行子应用lifespan。
3. 装配完成后依原顺序调用 recover_interrupted_grading_tasks、recover_diagnosis_pending_runs、recover_interrupted_paper_imports，各在该业务进程启动阶段调用一次。沿用“中断任务标记/诊断待恢复”等语义，不自动重放模型调用、不新增恢复队列。尚未装配时不调用；单次请求、健康轮询和诊断均不再次调用。未预期异常或依赖失效导致启动阶段未完成时，Business Ready=false并保留原因；旧函数允许的逐运行跳过仍须可解释，不据此声称该运行已恢复。
4. 授权诊断分项检查PG/vector/migration/schema/Redis/目录（文件仅创建并清理本次探针）。初始化预览展示环境、目标、current_head/target_head；用户确认后仅执行已审查的非破坏性迁移。未知结构/破坏性路径需独立审查，已有库不自动清空。它不等于依赖安装，也不负责账号创建。
5. 首次缺JWT时Windows安全生成保存，Docker要求外部Secret；旧账号仍沿原受控流程建立。只保存草稿/向导进度无需重启。若本进程启动时未装配业务，补齐依赖或完成初始化后必须重启，即使诊断已显示前置条件通过；此时 business.assembly=not_mounted、Business Ready=false、restart_required=true。pending配置的候选诊断与运行中effective配置分开，不将候选成功冒充当前就绪。
6. Windows由Launcher受控排空并重启自有worker，忙时保留pending并拒绝强杀；Python/Docker给手工重启指引。新进程重新检查前置条件、装配并调用恢复钩子一次，成功才Business Ready。初始化API和/ready不直接调用恢复钩子。
7. 已装配进程中临时PG/Redis故障使Business Ready降为false，恢复后依赖重检可重新ready，不重复装配/恢复。若改变DB/Redis/存储/JWT等配置，仍须按§2.4重启。AI缺失只阻止依赖该能力的业务操作；无AI的原授权业务保持可用。

### 5.3 HTTP语义

/health只表示进程存活；/setup-ready表示Setup Ready；/ready仅Business Ready，未装配/恢复阶段未完成/依赖失效均503。三个公共端点仅安全概览，不执行迁移、授权、付费Probe或Workflow恢复；详细检查来源与逐AI状态见授权/api/settings/readiness。
Compose healthcheck仍用/ready，Bootstrap期间unhealthy但服务保留，不以健康重启循环杀向导；backend启动HTTP不等待DB/Redis容器healthy。

首次可见增量见tasks的E1：T218只接根应用，T219提供前置诊断；E1未接入凭据后端时只报告credential_backend_unavailable/not_evaluated，不把已有秘密误报失效、不尝试匿名回退连接；完整凭据解析与相应认证连接诊断在T220汇合；业务装配及恢复协调接线由T220在T215业务保护通过后完成。E1本身不宣称Business Ready、完整向导或可发布。

## 6. 运行快照与历史兼容

运行快照包含有效非敏感配置、绑定 Profile 修订、credential_ref/version、请求模型、Prompt/Schema 版本、检索/阈值、索引身份；从最早应用服务调用创建并传至全部消费者，不能由下游重新 get_settings。配置服务按 snapshot 管客户端释放，不在全局缓存中替换原实例。恢复直接读取已保存的有效值，不重新叠加当前环境变量、默认值或当前任务绑定。process_env 秘密引用只属于原进程实例，跨进程不可自动重绑定；需要可恢复真实运行时使用持久凭据后端。

快照持久于配置环境的 config/snapshots；Workflow 状态/检查点增加 snapshot_id 及必要来源字段并升级 payload version，支持读取原版本。现有 WorkflowRun.checkpoint（JSON）与 LangGraph 持久检查点是运行事实源，不新增并行状态表。普通出题/阅卷结果沿现有 metadata 记录实际调用模型与 prompt，并引用 snapshot_id。备份将被非终态运行引用的非敏感快照纳入一致备份集，秘密不进备份。

旧 Workflow 缺 snapshot 明示 legacy_unknown；接纳时冻结当前 legacy baseline，存在旧非终态运行时拒绝相关模型/策略激活，继续原恢复合同，历史来源不回填。新运行一律完整快照；升级前即无法恢复的问题不能被本批虚报解决。

索引身份保存在 KnowledgeBase 新的可空 embedding_identity JSONB（登记事实，不改 vector 维度）。新库首次摄取原子登记 provider/model/version/dimension/语义参数；每次查询和摄取检查兼容身份。旧有向量为 unknown：保留既有配置读取模式并标未验证，阻止更换；只有操作者提供原部署/benchmark来源证据并显式接纳为兼容基线后允许继续新增摄取，不把该记录伪造成旧向量生成时间。受控接纳由设置中心“索引兼容性”进入：先查看KB标识、实际维度及旧身份unknown，再提交脱敏原部署/摄取/评测证据，预览可接纳身份和冲突，确认后原子保存legacy_adopted及审计事实。不能拿当前配置或一次新Probe当历史证据。API、证据字段和并发规则分别见settings-api §6、data-model §7；T214实现服务，T220接API，T228接UI，T211/T238验证。维度/语义不兼容需要独立重建 Feature；本批不实现重建。

## 7. Development / Test / Demo

| 资源 | Development | Test | Demo |
|---|---|---|---|
| PG | 显式接纳旧业务DB | 专属 eduagent_test DB/角色；每运行随机schema；备份测试专属测试实例 | 独立 eduagent_demo DB/角色 |
| Redis | dev实例 | 独立实例，key含环境+run_id | demo实例 |
| Windows数据根 | %LOCALAPPDATA%/EduAgent/development | %LOCALAPPDATA%/EduAgent/test/runs/run_id | %LOCALAPPDATA%/EduAgent/demo |
| Docker | eduagent-dev 项目 | 沿用M0 eduagent-test与既定端口 | eduagent-demo 项目 |
| 文件/日志/缓存/temp | 根内分目录 | run专有目录 | demo根内分目录 |
| 配置/秘密 | 环境独立 | Fake/隔离测试秘密 | 独立Secret或DPAPI |
| 评测输出 | 环境results/run_id | test/results/run_id | demo/results/run_id |

旧 storage 和DB不会因默认目录变更而移动或变空：首次接纳须预览旧资源位置并记录引用，禁止把正在用的旧库配上空新storage。路径含环境及实际目标身份；每次测试前由连接读取 current_database/user/schema，与 Test 资源计划匹配；凭 test 字符串前缀不足以授权删除。

文件清理只处理本次manifest列出的已解析绝对路径，拒绝根目录/父路径、重解析点逃逸与其他环境。数据库清理使用本次创建返回的schema/库所有权，禁public/业务schema；禁Redis FLUSHALL和共享卷 down -v。Test角色不能写dev/demo库。现有M0独占端口保护继续保留。

## 8. UI、API 与交付

React路由：/setup、/settings、/diagnostics；默认入口根据 setup 状态导航。生产以FastAPI同源提供已构建资源，设置API路由不得被SPA fallback吞掉。开发Vite代理到本机后端，精确允许该开发Origin；生产不开放开发Origin。无ServiceWorker缓存配置/密钥；秘密仅输入内存，提交后清空。

后端 OpenAPI 为 DTO 事实源，类型生成不需加载业务DB或真实模型；构建验证返回字段绝不包含secret value。不会将领域服务搬至前端。进入 /gradio 明确旧登录；不在本批共享或复制 JWT 到新长期浏览器存储。

Windows沿用onedir、worker所有权、外置持久目录；拆除Tk旧明文编辑路径的默认入口，保留经用户明确选择的旧配置导入功能；失效时显示安全诊断而非退回明文编辑器。Docker多阶段构建产前端资源并拷入后端，不增加第四服务；配置volume/secret引用按环境挂载。构建回执记录依赖/源码用于追溯，不制造相等版本门禁。

## 9. 回退、风险与验收门禁

| Gate | 条件 | 失败处理 |
|---|---|---|
| G0 范围与基线 | quickstart §0.1活动路径只读核对、保护旧任务/未提交修改、三层基线、具体TCR及产品决定 | 仅暂停受影响变更 |
| G1 隔离/持久 | 三环境及跨环境拒绝、原子保存/来源/损坏恢复 | 拒绝写入；保留原配置/资源 |
| G2 秘密与权限 | DPAPI/Secret、无泄露、未授权/跨源/过期拒绝 | 设置可诊断，不降级明文 |
| G3 Provider | Registry真实能力、八类Probe、费用/取消/释放 | 候选保留草稿，原active不变 |
| G4 Bootstrap | 无DB/Key设置可达，ready不虚报，迁移/重启有目标与所有权 | 保持Setup并显示原失败 |
| G5 双交付UI | 真实EXE和Docker静态资源、浏览器、持久化/退出 | 不以源码运行代替发布验收 |
| G6 业务保护 | 快照跨重启、索引兼容、审核/最终化/客观评分/RBAC回归 | 禁止模型激活，保留旧语义 |
| G7 质量与证据 | 既有pytest/mypy/ruff、前端构建/类型、相关契约/集成、显式real记录 | 记录真实fail/skip/not_run，无伪成功 |

回退对象是配置修订和应用包，不自动downgrade用户数据库。新增可空索引身份字段保持旧代码读取兼容；旧包不理解安全存储，故不能承诺直接回退旧明文启动器可用。回退时保留v3安全引导/经评审的兼容包，或在隔离副本人工恢复已保留旧部署；不得导出新密钥成明文。跨版本恢复前核对schema/checkpoint兼容，未获批准不自动破坏性迁移。

主要风险为旧入口隐藏 get_settings、旧全局缓存、缺历史模型身份、打包生命周期以及Docker授权经NAT差异；均有具体任务和验证。纯净机依赖安装和未来无登录迁移不作为本批阻断项。

## Complexity Tracking

无需要豁免的宪章违规。配置文件库解决DB自举，凭据服务解决持久秘密，运行快照解决暂停恢复，最小React由用户确认；不增加远程配置中心、通用插件运行时、独立Worker或统一重写所有AI逻辑。


## S0合同确认（T193，2026-10-10）

已核对当前spec、plan、contracts和analysis-report F01–F08，见[s0-preparation-report.md](s0-preparation-report.md)。技术路线、四层状态、Probe接纳事实、历史索引证据接纳及旧JWT/RBAC/Gradio保留确认；Origin按安全读取/敏感操作区分缺失头。后续无登录和全业务React仍属roadmap独立版本。T193完成表示合同核对完成，不表示源码实现或所有后续测试获长期授权。
