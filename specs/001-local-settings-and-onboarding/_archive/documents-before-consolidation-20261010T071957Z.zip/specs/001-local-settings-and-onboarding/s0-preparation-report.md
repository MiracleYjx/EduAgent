# EduAgent v3.0 S0实施准备报告

日期：2026-10-10。范围：仅T192–T195；基线deepcode / e89458156d15b10a2a0ae9ac3af5d20ca2dc9229。技术路线和F01–F08引用[前轮规划复审](analysis-report.md)，本报告只补S0实际证据及必要Origin修订。

## Review Result

**Accept with Conditions**。S0四项准备产物已经完成；专属Test资源的实际准备/连接身份/权限仍pending。没有源码实现、业务测试、DB操作、模型调用、构建、部署或提交。下一轮S1必须另有用户确认，不能自动推进T196。

本轮使用实际安装SpecKit 1.0.3 implement技能的任务、检查清单和DoD规范受控操作。先按quickstart §0.1通过过程级SPECIFY_INIT_DIR/SPECIFY_FEATURE_DIRECTORY与check-prerequisites.ps1 -Json -PathsOnly解析并恢复过程变量；没有运行会持久化Feature指针的-RequireTasks/-IncludeTasks常规helper，没有运行全任务自动推进命令。
路径结果的BRANCH是Feature标识001-local-settings-and-onboarding；实际Git分支为deepcode。没有.specify/extensions.yml，前后hook不适用。仅核验已有.gitignore/.dockerignore，不修改忽略文件。内置requirements为16/16，自定义readiness为0/24勾选；沿用逐项独立文档评审证据，在用户明确S0授权下执行本轮，不把未勾选项改为实现通过。

## Completed Tasks

| 任务 | 实际完成状态与Definition of Done证据 |
|---|---|
| T192 | 完成：真实绝对路径/HEAD/分支、Git差异、535项保护文件和14份原Feature指纹、私有配置整体hash、脱敏环境与7份历史来源指纹固化；旧指针和旧任务未修改。动态均not_run。见[audit](audit.md)和[B0清单](evidence/s0-b0-manifest.json)。 |
| T193 | 完成：下表核对F01–F08及确认技术合同；定点补settings-api §1.2、spec FR-023、plan §3、T216/T217安全读写来源矩阵。无新架构决策，后续版本边界保持。 |
| T194 | 完成的是资源计划：专属Test库/角色/随机schema、Redis、文件根、端口、Provider与清理责任明确；实际未核验的资源pending，无创建/清理。见[资源计划](resource-plan.md)。 |
| T195 | 完成：[首批具体TCR](../../docs/test-change-record-local-settings.md)按既有模板记录必要性、文件/固定场景、旧断言、预期失败、B0/B1/B2和停止条件；测试源码/执行为0，未预填passed。 |

仅T192–T195标[X]；T196–T239保持未完成，历史T001–T191状态不变。48项任务ID和依赖不变，状态为4完成/44未完成；依赖图仍无环。

## B0 Baseline

- 实际分支deepcode；HEAD e89458156d15b10a2a0ae9ac3af5d20ca2dc9229。Spec/Plan/Tasks绝对路径均为D:/YJX/MyCode/EduAgent/specs/001-local-settings-and-onboarding/下相应文件。
- B0开始已有.gitignore的一行用户新增/项目相关技术栈.md；Feature已有14份未跟踪Markdown。本轮不清理或覆盖用户差异。
- .specify/feature.json内容仍为feature_directory=".specify"，SHA-256为3F61275BCCDDFFC1D359A848D1E02A222F24ECA7CFC46DF8D479751F6581F535。仅本过程解析当前Feature，没有切换旧指针。
- 535项保护文件含backend/tests/migrations/脚本/打包/依赖/运行配置/旧SpecKit资料；原Feature指纹在发生本轮文档修改前保存。私有.env和真实Windows config.env只保存整文件完整性hash；没有读取密钥值、URL值或SDK正文。
- 普通Python源码仍隐式.env；Windows真实用户config.env存在。代理进程存在DEEPSEEK_API_KEY覆盖只证明存在性，不证明应用实际生效来源或Key可用。非提升进程LOCALAPPDATA重定向到沙盒，真实路径已单独只读核对，不能拿沙盒不存在结果推断用户配置丢失。
- 历史2662/0/1测试快照对应8d92c44，Windows实际包/重复计时对应2026-10-07来源，Docker/M0/backup对应2026-10-06旧独立资源。完整出处及失败保留见audit；不合并统计，不将旧回执视为当前HEAD通过。
- 本轮业务测试、DB/Redis连接、真实/假业务模型、EXE/Docker构建/验收、浏览器均not_run。docker ps的healthy是只读容器摘要，不能代替业务就绪。B1/B2尚未产生。

## Resource Plan

Test拟用专属PostgreSQL实例eduagent_test / eduagent_test_runner、每run随机schema和owner收据；备份维护角色只作用于该隔离实例。Redis为独立eduagent-test实例，所有config/storage/cache/logs/temp/results/credentials在独立Test run根。保持M0项目eduagent-test与loopback15432/16379/18000；Demo另用eduagent-demo和拟25432/26379/28000。

当前只见默认eduagent-postgres-1、eduagent-redis-1发布5432/6379。Test实际库/角色权限/pgvector/迁移head、独立Redis、目录和卷归属、端口可用性全部pending；选定端口的原生监听查询空结果不能推导Docker端口空闲。没有创建任何运行资源、哨兵或清理既有卷。
禁止用Development/Demo替代；Fake/Mock默认，测试入口不继承真实Key。哨兵仅合成验收副本；清理只凭本run创建事实和实际owner，失败留残留、停止扩大删除。

## TCR

TCR-S1-ENV-CONFIG-001范围仅T196–T203。具体拟新增environment/sources/cleanup guard/config persistence/environment paths测试；必要修改postgres_helpers、M0脚本、backup仅限Test护栏接线，保留原M0固定项目/端口及备份失败/完整性断言。旧JWT/RBAC/归属、Workflow轮次/分值/最终化、客观题零LLM、1024向量、结构化输出、历史unknown与恢复安全均不放宽。

先行行为失败仅静态预期，实际not_run；不能以ImportError或资源未就绪当目标红灯。下一批若改具体文件/合同须先补TCR。Origin矩阵归后续T216前的具体TCR，本轮只定合同，无测试代码。

## Findings

### F01–F08合同复核

| 项目 | S0复核结论/依据 |
|---|---|
| F01 路径保护 | 只读PathsOnly实际解析正确且旧指针未变；每次技能重入仍先quickstart §0.1，不能靠本轮结果永久跳过。 |
| F02 启动/装配 | Setup、Business Prerequisites、Business、逐任务AI四层保持。plan §5/settings-api §5为前置→装配→原三个Workflow恢复钩子每进程一次；无循环。未装配修复后须受控重启，/ready未装配仍503，/health只存活、/setup-ready只设置层。 |
| F03 Probe | settings-api §4.1/runtime §2：10分钟只约束新候选激活接纳；active/pending持久activation_validation，不因时间轮询/重启自动检测或付费。 |
| F04 重新授权 | plan §3/settings-api §1.1：Launcher“打开设置/重新授权”和持续自有worker管道；一次码过期、刷新/关页重开/长期会话到期有明确路径。Token仅内存，无公开HTTP领码或新后台服务。 |
| F05 历史Embedding | settings-api §6/data-model §7/plan §6：查看unknown→可核验历史证据→预览→明确确认→身份/审计同事务；T214/T220/T228责任完整；当前配置/新Probe不是历史证据，无自动重建。 |
| F06 早期增量 | 保持T203→T216→T217→T218→T219→T221→T222；不等全部AI快照/索引。T220仍依赖T210/T215；E1不开放秘密写/迁移/模型激活或假业务ready。 |
| F07 基线 | B0只静态/历史、B1护栏后、B2后续回归；无法可比时归因未定。T203不能冒充修改前。 |
| F08 清单 | readiness原24项独立证据仍适用，本轮未自动勾选；16/16内置自检不代替独立评审/实现回执。 |

Python/FastAPI/LangGraph、最小React/TS/AntD、Windows DPAPI、Docker外部Secret和隔离合同保持；旧JWT/RBAC/Gradio/User/Role业务仍保留。无登录、全业务React仍后续；本批无Rust/Prefix Cache/AI Reviewer模型迁移。

### 本轮实际问题

| ID/严重度 | 文件/证据 | 影响与处理 |
|---|---|---|
| S0-01 HIGH（文档已修正） | 原settings-api §1统一要求匹配Origin；同源GET/HEAD允许无Origin，见[WHATWG Fetch Origin header](https://fetch.spec.whatwg.org/#origin-header)。 | 原规则可能误拒正常读取。§1.2区分安全读与敏感写：GET/HEAD缺Origin仅在有效Token+精确Host下允许；有非法Origin总拒绝；所有写和exchange/Probe/诊断必需合法Origin。无放宽权限、跨站写或通配CORS。Spec/Plan/T216/T217对齐；实现验证尚not_run。 |
| S0-02 MEDIUM（资源pending） | resource-plan §1；只读docker ps仅默认项目 | 不能安全开始真实集成/基线。下一轮在专属Test准备并核验实际身份后进入，不能改用现开发库。 |
| S0-03 LOW（证据边界） | audit B0历史来源；本轮动态not_run | 当前HEAD动态通过状态未知。后续T203建立B1且保留不可归因，不冒险运行旧helper补B0。 |

以上是已确认实际证据，不据规划完成声称运行就绪。无需新增重大架构裁决。

## S1 Admission

S0文档前置已经满足。**本轮不进入S1；等待下一轮用户确认。**
确认后T196/T197/T198/T200及符合依赖的T201可用隔离tmp_path/Fake推进；不因专属资源pending暂停不依赖它们的工作。T199/T202/T203实际访问PG/Redis/文件资源前必须完成resource-plan的身份、权限、owner、哨兵和清理核验并先完成T199护栏。T203退出须完整B1及相关失败处理，才可进入E1或AI保护分支。再次核对Feature/HEAD/差异和具体TCR，不能沿旧指针执行。

## Changed Files

均为S0所需文档，不修改运行配置/源码：
- audit.md：B0事实、来源、未运行边界；evidence/s0-b0-manifest.json：原始指纹/只读观察审计清单。
- resource-plan.md：专属资源计划和pending；quickstart.md：引用S0资源与基线。
- contracts/settings-api.md、spec.md、plan.md：必要Origin安全读取/写入区分和合同确认；tasks.md：T216/T217覆盖文字、仅T192–T195完成标记/证据。
- test-change-plan.md、../../docs/test-change-record-local-settings.md：首批具体TCR及相互引用。
- analysis-report.md：补S0状态，保留原复审的历史结论；s0-preparation-report.md：本报告。

现有/docs/忽略规则使新TCR不出现在普通Git未跟踪列表；文件实际保存在指定路径，未改.gitignore、未强制add。

### S0文档核验回执

12份本轮修改/新增文档已逐一回读并核对实际内容；149个本地文档引用无失效；48个唯一任务、4完成/44未完成、0缺失依赖/0环，54项需求映射完整，直接依赖未改变。6份未修订Feature文件与原B0一致，requirements保持16/16，readiness保持0/24勾选。

535项保护文件、2份私有配置整体hash和7份历史回执均与B0一致；旧Feature指针及历史任务未变。主机只读Git确认已跟踪差异仍仅用户.gitignore新增1行，Feature仍未跟踪；新TCR由原.gitignore:5的/docs/规则忽略。沙箱Git的“必须在工作树”误报通过主机只读查询核对，未改Git设置。以上为文档/完整性验证，产品测试仍not_run。

## Decision

**等待用户确认下一轮S1。** S0完成即停止；不自动T196、不创建运行资源、不执行业务测试、模型、构建、部署或Git commit/push。
