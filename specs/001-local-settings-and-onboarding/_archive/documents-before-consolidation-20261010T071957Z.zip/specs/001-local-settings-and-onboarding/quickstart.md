# Quickstart：未来实施后的聚焦验证

当前日期2026-10-10，本轮已完成S0 T192–T195文档准备；以下产品实施验证步骤均为 **not_run**（§0.1只读路径检查已执行，不是产品测试）。新API、前端、profile入口和测试文件尚未实现；本文件不是现有系统可直接照跑的完成声明。详细接口见 [contracts/settings-api.md](contracts/settings-api.md)。

## 0. 准备与停止条件

先完成每批具体TCR，使用专属Test数据库/角色、Redis实例、文件根和FakeProvider；任何连接指向development/demo立即停止，不能为跑通验证改用用户库。保留两套非Test哨兵。DB/Redis安装、模型下载和迁移不能在未审查目标时自动执行。

记录：代码/包标识、环境profile、实际连接身份、数据/Prompt/模型版本、输入来源、命令、UTC时间、退出码、失败/skip、清理回执；秘密不进记录。实际包测试按docs/evaluation.md冷暖/重复协议，人工输入/服务安装另计。

### 0.1 每次进入SpecKit前的活动路径确认（只读）

安装版本为1.0.3，旧.specify/feature.json仍指向.specify。仅设置SPECIFY_FEATURE_DIRECTORY并不保证不写指针：common.ps1中Get-FeaturePathsEnv默认持久化；setup-plan/setup-tasks及不带PathsOnly的check-prerequisites会调用它。本轮不得运行这些会写状态的helper，也不得覆盖旧指针。

在仓库根执行下列只读预检，记录FEATURE_DIR/三个主文档/旧指针前后指纹；失败立即停止依赖该路径的技能。指纹只用于证明本轮未改指针，不作为产品运行版本门禁。

```powershell
$reviewRoot = (Resolve-Path -LiteralPath '.').Path
$expectedFeature = (Resolve-Path -LiteralPath (Join-Path $reviewRoot 'specs/001-local-settings-and-onboarding')).Path
$pointerPath = Join-Path $reviewRoot '.specify/feature.json'
$pointerBefore = (Get-FileHash -LiteralPath $pointerPath -Algorithm SHA256).Hash
$priorInit = $env:SPECIFY_INIT_DIR
$priorFeature = $env:SPECIFY_FEATURE_DIRECTORY
try {
    $env:SPECIFY_INIT_DIR = $reviewRoot
    $env:SPECIFY_FEATURE_DIRECTORY = $expectedFeature
    $paths = & (Join-Path $reviewRoot '.specify/scripts/powershell/check-prerequisites.ps1') -Json -PathsOnly | ConvertFrom-Json
    if ((Resolve-Path -LiteralPath $paths.FEATURE_DIR).Path -ne $expectedFeature) {
        throw 'Feature path mismatch'
    }
    foreach ($name in @('spec.md', 'plan.md', 'tasks.md')) {
        $file = Join-Path $expectedFeature $name
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing $name" }
    }
    $paths | Select-Object FEATURE_DIR, FEATURE_SPEC, IMPL_PLAN, TASKS
}
finally {
    $env:SPECIFY_INIT_DIR = $priorInit
    $env:SPECIFY_FEATURE_DIRECTORY = $priorFeature
    if ((Get-FileHash -LiteralPath $pointerPath -Algorithm SHA256).Hash -ne $pointerBefore) {
        throw 'Feature pointer changed unexpectedly; stop and review'
    }
}
```

PathsOnly仅解析，不验证文档内容；上面的存在检查和后续Spec/Plan/Tasks一致性评审缺一不可。之后读取/修改均使用已核对绝对路径，不能退回旧指针；新进程不保证继承本次env，必须重新执行预检。

未来实施优先继续显式路径和NoPersist等价前置检查，随后按技能规则处理此Feature，避免调用持久化helper；不得声称已完整执行未运行的标准脚本。若后续必须使用会写指针的标准流程，须把旧/新值及恢复方式单列为元数据变更取得授权后再做。本轮不作该切换。Git实际分支仍单独以git核对，不把Feature目录名当分支。

### 0.2 三层取证

T192在源码修改前保存B0静态身份/差异/既有运行回执来源；无法安全运行旧测试就标动态证据not_run。T203的B1是T196–T202护栏及配置修改后的当前基线，不能追认为修改前。后续B2回归须引用可比B1及本次差异，原失败归因证据不足时标unknown。详见test-change-plan；不因要补B0而冒险运行旧清理逻辑。

### 0.3 S0资源准备记录

T194已形成[resource-plan.md](resource-plan.md)：专属Test库/角色、随机schema、Redis、目录、M0端口、哨兵和cleanup计划；实际准备/权限核验pending。本轮没有创建运行资源，下一轮真实资源验证前重查目标，不能用原Development代替。B0见audit与evidence清单；T195具体记录见../../docs/test-change-record-local-settings.md。

## 1. 空配置与状态分层（US3；G4）

Windows真实包选择全新Development验收副本（不可用用户默认目录），不提供数据库/模型/JWT配置；双击后记录Setup Ready及设置页面截图。/ready应503。缺数据库与Redis分别重做诊断，页面仍可用。缺前端dist时Setup Ready也不能200。

提供独立Test依赖与目录，通过初始化预览核对数据库身份/head，显式确认允许的迁移。诊断即使Business Prerequisites通过，未装配进程仍/ready503并提示重启；重启装配原业务、调用原三个恢复钩子一次后/ready才200；未配AI仍标具体任务missing/unverified。已装配进程短暂断连再恢复不重复装配/钩子；初始化请求和健康轮询不调用钩子。旧业务保持登录。来源/密码不在浏览器读取响应。

## 2. 配置保存及权限（US1/US4；G1/G2）

先从本机launcher获得一次授权，确认第二次兑换、过期token、错误Host、跨源及无token Probe均拒绝。分别覆盖一次码过期、刷新、关页重开、闲置10分钟及绝对30分钟：回到Launcher控制窗口重新授权，GET已保存进度，不自动重放旧请求；关闭浏览器不退出Launcher，重复EXE不接管已有实例。两个浏览器同时编辑同修订，第二次保存409。
保存本地值再增加受控进程覆盖，检查来源、覆盖提示和effective=false。坏覆盖不能偷用原值。分别注入只读目录、磁盘写失败、损坏配置、未来schema，原active不变，恢复须显式选择。重启不能丢失已保存草稿。

## 3. Provider与费用（US2；G3）

先Fake/Mock逐一证明八类结果、unknown、取消、本地缺资源，不发真实外网请求。确认Reviewer为规则、不显示可选模型；未注册Provider不可保存为可用。LLM text成功不把Vision/Embedding标成功。
经明确真实调用授权后，用固定无业务数据样本分别检测所选能力；UI展示每次可能收费，单次外部请求<=1，无隐式retry/fallback。记录实际耗时/usage（未知保持null）。失败/超时/取消不换active或旧密钥引用。更换profile/credential后旧检测不能授权新候选。用Fake时钟分别验证未激活候选超过10分钟被拒、已激活绑定超过10分钟仍可使用、pending普通重启不重测；状态轮询/开页/等待带来的外部模型请求数均为0。保留实际网络失败，不能让计时器制造离线。

## 4. 凭据生命周期（G2）

Windows同用户保存后退出重启读取成功；密文损坏/其他用户不能解密时显示reentry_required，不落回.env。对测试秘密原文检查普通配置、响应、错误、Trace、Audit、benchmark、浏览器持久存储和诊断输出，出现次数必须为零。检查DPAPI输出内存/客户端释放路径，真实冻结包单独证明。

Docker只读Secret缺失/被撤销/版本轮换，UI给出外部管理步骤；Windows写入API在Docker405。检查localhost发布后的合法请求不会因NAT误拒，同bridge无token请求仍拒绝。服务日志不含一次授权码/秘密。
删除被active/pending/暂停运行引用的凭据应409；解除引用后的删除必须真实成功后才更新状态。业务备份恢复不带秘密，需重录/重新挂载后再检测。

## 5. 运行快照与索引（US5；G6）

准备客观题+主观题、低置信度暂停的实际测试Workflow。绑定A启动，激活B后创建新任务；旧运行仍A、新运行B。重启后恢复旧checkpoint，actual model/prompt/config引用保持。删除旧秘密被拒；模拟外部撤销时恢复明确失败且不切B。人工复核、规则评分、考试分值、最终化与诊断原断言继续成立。

旧版本payload无snapshot应保留legacy_unknown；冻结其已接纳基线，未终结前相关配置激活拒绝，原恢复路径仍可用。不可将新snapshot写成历史已知。

有向量库分别尝试非1024维及同维不同模型，均拒绝，不改向量。旧无身份库显示unknown；没有接纳证据不新增混合向量。进入设置“索引兼容性”，经身份详情→脱敏历史证据→预览→确认→读回，核对legacy_adopted及操作者/前后身份/证据审计；测试缺证据、冲突、过期及审计写失败均不改变旧身份或向量，备份恢复保留审计。空知识库首次原子登记，两个不同模型并发不能混入。无需运行索引删除/重建。

## 6. 隔离与回归命令（US1/US6；G1/G7）

未来profile入口实现后，先输出并检查ResourceManifest，再执行下列既有框架命令；不要在当前缺统一Test护栏的仓库直接执行全量测试。

```powershell
# 前提：本进程已通过显式Test目标预检，凭据以受控方式注入。
python -m pytest tests/unit/settings tests/contract/test_settings_api.py tests/integration/test_settings_lifecycle.py
python -m pytest
python -m mypy backend/app
python -m ruff check backend/ tests/
```

实际命令以仓库已安装工具为准，不因缺工具自动安装。前端未来锁定npm脚本：类型检查、单元测试、production build和生成DTO漂移检查；应由T224/T231写入真实入口，当前不伪造可执行脚本。

全量中M0/真实DB/Windows权限等skip必须明确原因；不能把skip算通过。运行后检查dev/demo哨兵未变，本次Test资源按manifest清理；清理失败记录残留而不扩大删除范围。普通回归请求计数证明付费模型0次，真实评测单独启用并保存结果。

## 7. 实际交付（US6；G5）

- Windows：构建后onedir在独立路径启动，无源码目录/Node依赖，React资源和/gradio真实打开；首启、中断、重启、端口冲突、DPAPI和仅退出自有进程各有回执。
- Docker：独立项目/卷、模型Secret缺失和数据库故障时HTTP设置可达；/ready保持503；修复初始化后核心ready。不能把healthcheck的unhealthy当理由重启循环杀死向导。
- UI：1366×768和1920×1080，键盘、错误焦点、来源、只读secret、费用、待重启、旧登录跳转；离线无CDN。
- 原业务端到端：教学资料、导入/校正、生成/审核、组卷/考试、阅卷/复核/诊断、文件备份恢复，使用受控输入及当前独立资源。新配置系统不重新判定旧业务语义。

## 8. 交付判断

必须区分：文档一致→源码实现→测试通过→构建成功→运行加载→系统验收→发布回执。仅本批既定门禁通过后才能声明第一批交付；真实模型未跑则列未验证能力，不猜测效果。规划完成后本轮停止，不执行上述步骤。
