# S0 Development / Test / Demo资源计划（T194）

记录日期2026-10-10，主机只读观察UTC 2026-10-10T06:29:28.5812984Z。本文件是资源准备计划；本轮没有创建数据库、角色、schema、volume、哨兵或运行数据目录。基线与命令结果见[evidence/s0-b0-manifest.json](evidence/s0-b0-manifest.json)。

## 1. 资源矩阵与当前状态

| 资源 | Development保护对象/计划 | Test拟用目标 | Demo拟用目标 | Test/Demo状态 |
|---|---|---|---|---|
| PostgreSQL | 当前默认eduagent项目已有PG；实际库/角色未查询，不当Test | 专属实例中的eduagent_test库、eduagent_test_runner角色；pgvector(1024) | 独立eduagent_demo库/角色 | pending：库/角色/ACL/扩展/head未验证 |
| Schema | 原业务schema不创建/清理 | 每run随机test_<run_id_hex>；创建返回owner与实际目标写manifest | demo业务schema独立 | pending：没有本轮schema或创建收据 |
| 备份恢复 | 原库保持、不恢复覆盖 | 同专属Test实例的每run新目标库；单独维护角色仅用于该隔离实例，不借dev凭据 | 使用隔离副本验收 | pending：实例隔离/创建库权限未确认 |
| Redis | 当前eduagent-redis-1保持 | eduagent-test独立Redis实例；key含environment_id/run_id | eduagent-demo独立Redis | pending：实例/归属/数据隔离未验证 |
| Windows根 | 未来development根需显式接纳旧位置，旧配置/storage不移动 | C:/Users/10169/AppData/Local/EduAgent/test/runs/<run_id>/ | C:/Users/10169/AppData/Local/EduAgent/demo/ | pending：本轮不创建这些根 |
| 文件子目录 | 原用户文件保持 | config/storage/cache/logs/temp/results/credentials均在该run根；合成秘密独立 | 相同子目录在demo根 | pending：写权限与边界护栏在S1实现/验证 |
| Docker项目 | 当前eduagent保留；未来eduagent-dev只是已规划目标，禁止抢占旧实例 | eduagent-test（保持M0固定名） | eduagent-demo | Test运行项目未见；旧停机容器/卷未检查，不能据此自动重用 |
| Docker端口 | 当前发布5432/6379，原业务通常8000；实际worker未确认 | host loopback15432/16379/18000 | 拟25432/26379/28000 | pending：非预留端口；执行前再次核对占用/归属 |
| Docker卷 | 当前postgres_data/redis_data保护 | 项目专属卷；如已有卷，先查归属/内容，不自动清空或接纳 | 独立demo卷 | pending：本轮不inspect内容/改卷 |
| Provider | 原真实凭据保护 | 默认Fake/Mock，固定合成样本；不加载父进程真实Key、不走外网 | 实调用显式授权，默认合成验证 | 普通回归为Fake；真实模型授权未取得 |

M0固定值来源：tests/integration/test_m0_smoke.py:21–27、scripts/smoke_m0.ps1:22–27。历史M0使用过eduagent_t190_m0_fixed及既有测试卷，不等于当前新Test准备完毕；不覆盖旧固定库。普通Test库eduagent_test与旧M0固定库分别记录实际locator；后续M0若复用历史库，必须先证明它为专属测试目标，不能因名字含test放行。

本轮docker ps只见eduagent-postgres-1、eduagent-redis-1（healthy）；这是默认项目运行摘要，非数据库/模型可用性验收。Get-NetTCPConnection选定端口没有返回记录，与Docker发布摘要不能推导“端口空闲”；以执行前目标归属检查为准，当前不预留端口。

## 2. Test权限与所有权

eduagent_test_runner只连接专属Test库、创建/拥有本run schema，不使用superuser、CREATEROLE或开发账号；拒绝对dev/demo库写入。扩展/建库由隔离实例的受控维护步骤准备，普通测试不静默安装。备份测试确需新建库时，只在专属Test实例经单独资源计划及TCR使用维护角色。

ResourceManifest记录environment_id、run_id、实例/host/port、实际current_database/current_user/current_schema、已创建schema/库、创建者/owner、已解析文件路径、Redis实例/key范围、创建时间与清理结果；秘密不写manifest。连接读取身份的实际核验留待获准的S1资源验证，本轮无DB查询。
清理授权来自该次创建事实及目标复核，不能靠test前缀、端口或哈希推断。首次使用前还需证明测试角色不能写dev/demo；该证明当前pending。

## 3. 哨兵和失败清理边界

后续在独立dev/demo验收副本放合成哨兵（行、文件字节、合成凭据引用），记录前后值/指纹；不为哨兵修改用户实际教学库。Test只创建本run合成资料，清理后非Test哨兵变化应为0。本轮未创建任何哨兵。

只清理manifest列出的本run资源：拒绝public/原业务schema、其他run、父/根路径、重解析点逃逸；禁FLUSHALL、共享卷down -v、删整个用户目录。每次实际清理前重新核对绝对目标/owner；清理失败记录残留并停止扩大删除，不生成成功回执。

## 4. 真实调用与准入

父进程观察到DEEPSEEK_API_KEY存在，只记录存在性。测试入口必须显式选择test与Fake，不继承该Key去构造真实客户端；本轮付费/普通模型请求均0。Real调用要有目标能力、样本、最大次数/超时和费用授权，不能靠Key存在启用。

S1本地/Fake部分可在下一轮确认后推进；真实PG/Redis、备份和集成部分待以上pending完成、T199护栏行为成立后进入。禁止用当前eduagent项目、原Windows配置或Development/Demo资源替代。
