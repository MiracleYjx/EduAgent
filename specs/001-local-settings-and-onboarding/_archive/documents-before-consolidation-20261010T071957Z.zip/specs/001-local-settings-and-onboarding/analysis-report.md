# SpecKit Focused Review — Local Settings and Onboarding

> 状态补充（S0，2026-10-10）：本报告主体为前轮规划复审，文中的“当前不执行/0勾选”属于该轮历史状态；本轮用户授权仅T192–T195，四项准备已完成，44项仍未完成。当前证据与条件见[S0实施准备报告](s0-preparation-report.md)。无业务实现/测试/资源操作，readiness复选框不变。

日期：2026-10-10。Review基线：deepcode / e89458156d15b10a2a0ae9ac3af5d20ca2dc9229；开始时.gitignore已有1行用户修改，Feature的14份文件尚未被Git跟踪。本报告替代第一轮“0歧义/0规划阻断”的过宽评价；实现差距的历史源码证据继续保留在[audit.md](audit.md)。F01–F08在本报告表示本轮规划发现，不沿用旧报告的实现差距编号。

## Review Result

**Accept with Conditions**。六个重点均需澄清或修订，已在本Feature中处理；没有因本轮复审改变已确认的技术路线，也无新增重大架构决策待用户投票。条件是实施时准确选中此Feature、固化B0、完成具体TCR与隔离准入，并按E1/完整向导/双交付的不同门槛取证。不是无条件批准实施或宣布代码已符合规划。

## Findings

下表“证据”保留修订前文本定位，行号仅指本轮读取的旧稿；处理后的条款以节标题/任务ID定位。所有HIGH在文档层已修订，尚未执行实现验证。

| ID | 严重度 | 文档路径/条款 | 证据 | 影响 | 处理意见及本轮处理 |
|---|---|---|---|---|---|
| F01 | HIGH | quickstart §0.1；tasks T192；.specify/feature.json | 旧指针为.specify；common.ps1:178–187在设置环境覆盖后默认Save-FeatureJson；普通helper不是只读。 | 技能可能读错旧Feature或未经许可改指针。 | 增加显式绝对路径+PathsOnly+文档存在+指针前后检查；后续每次重复。保留旧指针，本轮已只读验证。 |
| F02 | HIGH | plan §1/5；research R05；spec FR-019；data-model §8；settings-api §5 | 原plan:75图以Business Ready驱动装配，而FR-019把装配包含在Business Ready内；原§5未严格划分恢复阶段。 | 实现可形成装配循环或把依赖可连误当完整业务就绪。 | 定义Business Prerequisites→装配→原三钩子一次→Business Ready；未装配修复须重启，暂时依赖恢复不重跑钩子。 |
| F03 | HIGH | plan §2.3/4；data-model §2/5/8；settings-api §4.1；runtime §2 | 原plan:106与data-model ProbeResult只规定10分钟，没有接纳事实和持续使用的区别。 | 实现者可能定期降级AI Ready，要求用户重复收费检测。 | 新增activation_validation；TTL仅接纳新目标，未变active/pending保留；读取、计时、重启不自动Probe，目标变更才要新证据。 |
| F04 | HIGH | plan §3；settings-api §1.1；T216/T217/T221/T222 | 原plan:128仅写刷新/重开由启动器授权；实际windows_launcher.py:441–443发送SERVE后关闭stdin，453起只等worker退出。 | 令牌过期后没有实际用户恢复入口；容易被补成公开领码或浏览器持久化。 | 复用Launcher控制窗口与存续自有worker管道，注册确认再开页；过期/刷新/关页/长期重入路径完整，无新服务。 |
| F05 | HIGH | plan §6；data-model §7；settings-api §2/6；runtime §5；T211/T214/T220/T228/T238 | 原data-model:68只有evidence_reference/adopted_at；settings-api表没有查看/预览/确认入口，T214仅泛指接纳。 | 保护要求存在但操作者无法执行，审计和事务责任不清，可能把当前配置当历史。 | 补受控API/UI、逐字段历史证据、人工确认与服务核验界限；旧unknown与接纳身份并列，同事务保存审计，不改向量。 |
| F06 | HIGH | tasks T218/T219/T220/T221/T222/T223/T224；plan §5/8；roadmap | 原T218依赖T208/T210/T217，T219依赖T214，T222依赖T220/T221；反而T220的配置激活接线未显式依赖T215。 | 静态设置被AI/索引链阻塞，同时业务保护门禁在图中没有完整支配激活入口。 | E1拆为最小根应用/权限/基础诊断/外壳；完整装配、初始化及AI接线仍在T220且新增T215前置。任务不增删编号，完整向导移归T223。 |
| F07 | MEDIUM | tasks T192/T203；test-change-plan 基线证据分层；quickstart §0.2 | 原T203位于T196–T202修改之后，却要求区分既有/本批失败，没有明确修改前证据采集或不可归因规则。 | 护栏后的结果可能冒充修改前基线，失败被误归因。 | B0修改前取证、B1护栏后当前基线、B2后续回归分别记录；无可比证据标归因未定，不冒险跑旧清理逻辑。 |
| F08 | MEDIUM | checklists/readiness.md 独立复审；analysis-report | 旧analysis-report称功能歧义/未解决规划阻断均为0；24项仅生成，未逐项独立评价。 | 追溯率和内置16/16自检不足以证明本轮实施准入。 | 补24项逐一证据和前后判断：原稿18通过、6需修改；修订后建议通过但不自动勾选，不推断实现已完成。 |

## Required Changes

以下为已完成的定点修订，不重新生成Spec，不更改旧T001–T191：
- F01：quickstart §0.1提供过程级路径覆盖、PathsOnly解析、三个主文档存在及旧指针前后校验。标准helper的写副作用明确记载；未获元数据变更授权则使用NoPersist等价前置处理。
- F02：spec FR-019、plan §5、research R05、data-model §8和settings-api §5对齐四层状态。装配及原恢复在进程启动阶段一次完成；首次初始化/修复未装配进程后重启，候选诊断不混入effective就绪。
- F03：plan §2.3/4、data-model §2/5/8与两份合同区分Probe时间窗口和接纳事实；不以定时付费证明活性。
- F04：plan §3、settings-api §1.1及T216/T217/T221/T222落实Launcher持续入口和所有过期/刷新场景；旧JWT仍只管理业务。
- F05：data-model §7、settings-api §6、plan §6、runtime §5及T211/T214/T220/T228/T238对齐查看/证据/预览/确认/审计。服务能核验完整性、维度和一致性，不能将人工证据文本自动认作已证明的历史来源。
- F06：依赖修改见下一节；T222只提供E1，T223承担完整向导，T220必须在T215保护通过后接完整写入/业务装配；不以任务前移关闭任何保护测试。
- F07/F08：test-change-plan的B0/B1/B2和readiness逐项评审替代“当前基线=修改前”和“自检=独立验收”的隐含假设。

## Task Dependency Review

修订前、后均为48个唯一任务T192–T239、0勾选、0缺失依赖、0环。已对实际“依赖”字段做拓扑检查，不能仅凭编号递增推断。任务ID和原故事可追溯；7项直接依赖改变：

| 任务 | 修订前依赖 | 修订后依赖 | 职责说明 |
|---|---|---|---|
| T218 | T208、T210、T217 | T201、T217 | 根应用/静态/授权与业务导入隔离；完整装配交T220 |
| T219 | T218、T214 | T218 | 基础前置诊断及受保护API，不等待索引或AI |
| T220 | T219、T210 | T219、T210、T215 | 保留完整API/初始化，新增业务装配/AI/索引接纳接线并受T215支配 |
| T221 | T220、T217 | T219、T217 | 持续Launcher授权和自有worker控制可先完成 |
| T222 | T220、T221 | T219、T221 | 最小静态外壳/基础诊断E1；完整向导交T223 |
| T223 | T222、T219 | T222、T220 | 在E1和完整API都具备后接通并验证向导 |
| T224 | T222 | T222、T220 | 完整设置DTO依赖T220，避免对不存在接口造前端事实 |

E1路径：T203 → T216 → T217 → T218 → T219 → T221 → T222。T222前置祖先由27项减为17项，按任务节点数的最长链由18减为14；没有工时估算，不据此声称节省天数。T214及T204–T215均不再是E1前置，T203隔离基线、设置权限测试和真实业务拒绝仍是前置。未接凭据后端的检查显示credential_backend_unavailable/not_evaluated，不用匿名连接或假凭据绕过。

完整向导仍需T210/T215→T220及T222→T223；模型激活/原Workflow/Embedding保护并未从交付移除。完整交付仍由T231–T239证明，E1不等于完整Bootstrap业务装配或可发布包。

**范围审查**：未发现可直接删除而不损失本批保护的整项任务。T211–T215保护热更新/暂停恢复/旧向量，T238保护新增快照/索引审计随备份；不能削掉。T234/T235保留双交付实际证据。T237仍为显式授权的最小真实验证，无授权记not_run而不拖住独立本地/Fake工作。提前外壳及缩短依赖已解决首个可见结果过晚的问题，无需增加后台服务、重建向量或全业务UI迁移。

## Checklist Review

独立逐项证据及理由见[readiness独立复审表](checklists/readiness.md)。修订前18通过、6需修改（CHK007/012/013/014/015/019）；修订后这6项已有明确条款，24项均有建议通过的文档证据，复选框仍未自动勾选。没有用内置requirements.md的16/16代替任何一项判断。未取得的实现/包/模型证据仍为not_run，与“需求质量证据充分”不同。

| 项目 | 原稿判断 | 修订后建议 | 证据条款 |
|---|---|---|---|
| CHK001 | 通过 | 通过 | [plan §7](plan.md)、[data-model §1](data-model.md)、T194/T198–T203 |
| CHK002 | 通过 | 通过 | [plan §2.2](plan.md)、[runtime §1](contracts/runtime-configuration.md) |
| CHK003 | 通过 | 通过 | [data-model §2/4/6/9](data-model.md)、[plan §2/6](plan.md) |
| CHK004 | 通过 | 通过 | [spec Clarifications](spec.md)、[plan §3](plan.md) |
| CHK005 | 通过 | 通过 | [plan §4绑定表](plan.md)、[data-model §3](data-model.md) |
| CHK006 | 通过 | 通过 | [settings-api §4](contracts/settings-api.md)、[runtime §3](contracts/runtime-configuration.md) |
| CHK007 | 需修改 | 通过（修订后） | [plan §3](plan.md)、[settings-api §1/1.1](contracts/settings-api.md)、T216/T217/T221 |
| CHK008 | 通过 | 通过 | [spec FR-008/NFR-002](spec.md)、[data-model §4](data-model.md)、[test-change-plan](test-change-plan.md) |
| CHK009 | 通过 | 通过 | [plan §3](plan.md)、[data-model §4/9](data-model.md) |
| CHK010 | 通过 | 通过 | [settings-api §4](contracts/settings-api.md)、[spec FR-012/013](spec.md) |
| CHK011 | 通过 | 通过 | [plan §2.3](plan.md)、[data-model §9](data-model.md)、T200/T201/T210 |
| CHK012 | 需修改 | 通过（修订后） | [plan §6](plan.md)、[data-model §6/7](data-model.md)、[settings-api §6](contracts/settings-api.md) |
| CHK013 | 需修改 | 通过（修订后） | [plan §5.1–5.3](plan.md)、[data-model §8](data-model.md)、[settings-api §5](contracts/settings-api.md) |
| CHK014 | 需修改 | 通过（修订后） | [plan §3/5.2](plan.md)、[settings-api §1.1](contracts/settings-api.md)、[quickstart §1/2](quickstart.md) |
| CHK015 | 需修改 | 通过（修订后） | [plan §2.3/4](plan.md)、[settings-api §4.1](contracts/settings-api.md)、T207/T220/T223 |
| CHK016 | 通过 | 通过 | [spec FR-027/028与Assumptions](spec.md)、[plan §5.2](plan.md) |
| CHK017 | 通过 | 通过 | [plan §2.4/6](plan.md)、[runtime §4](contracts/runtime-configuration.md)、T211–T215 |
| CHK018 | 通过 | 通过 | [runtime §7](contracts/runtime-configuration.md)、[roadmap退役边界](roadmap.md) |
| CHK019 | 需修改 | 通过（修订后） | [test-change-plan基线证据分层](test-change-plan.md)、T192/T195/T203 |
| CHK020 | 通过 | 通过 | [spec FR-029/SC-010](spec.md)、[runtime §6](contracts/runtime-configuration.md)、T236/T237 |
| CHK021 | 通过 | 通过 | [spec NFR-005/006/SC-011](spec.md)、[plan §8](plan.md)、T230 |
| CHK022 | 通过 | 通过 | [spec SC-008](spec.md)、[quickstart §7/8](quickstart.md)、T231–T239 |
| CHK023 | 通过 | 通过 | [spec NFR-004/007/SC-012](spec.md)、[settings-api §4](contracts/settings-api.md) |
| CHK024 | 通过 | 通过 | [spec Context and Scope](spec.md)、[roadmap](roadmap.md) |

## Implementation Admission

- **T192–T195：技术上可以作为下一轮起点；当前不执行。** 本轮只是文档授权。下一轮有实施授权后，先执行quickstart §0.1；T192固化B0/保留用户差异，T193引用本轮独立评审确认既定合同，T194记录真实可用专属Test资源与未就绪部分，T195仅先写首批具体TCR。不得直接按旧指针启动技能，也不需要为了开始这四项先改旧指针。
- **进入T196–T203：** T192–T195的产物及对应TCR存在，Feature/工作区身份无误，首批配置/环境DTO合同明确。T196/T197/T198/T200/T201可用隔离临时目录和Fake推进；缺真实Test资源只暂停依赖它们的验证。T199/T202/T203实际访问资源前，必须校验专属DB/角色/Redis/目录/端口、实际连接身份和owner，证明不会写dev/demo；不能用配置名字代替此证明。每项测试修改先有具体TCR，原授权/评分/最终化断言不放宽。
- **T203退出条件：** B1清楚列出T196–T202差异、命令/失败/skip/清理/哨兵；相关失败已定位解决或明确仅阻塞受影响工作，无可比B0动态证据就保留unknown，不能预填既有失败。此后才进入E1权限分支和AI/保护分支。
- **后续门禁保持：** E1不接受秘密写入、初始化迁移或模型激活；完整G2/G3/G6及T215通过后T220接这些能力。旧Workflow恢复合同和Embedding限制贯穿T223/T231/T238。无付费授权、发布或旧指针修改授权均不得自行开展对应动作。

## Analyze 一致性与追溯

按安装的SpecKit 1.0.3 Plan、Checklist、Tasks、Analyze规则聚焦处理已有Feature。未运行会重建文档或持久化指针的setup-plan/setup-tasks/普通prerequisite；使用显式路径只读预检。无.specify/extensions.yml，前后hook均不适用。按用户修订授权先修正文档，再按Analyze六类规则做只读复核；保存本报告不代表调用过不存在的斜杠命令，不运行speckit-implement。

| 检查 | 结论 |
|---|---|
| 重复 | 状态/TTL/接纳规则通过交叉引用对齐；没有新增平行配置或Workflow事实源 |
| 歧义 | F02–F05已有明确主体、状态转换和失败路径；未将新证据接纳称历史已知 |
| 缺项 | API/DTO/领域事务/UI/验证责任对应任务；早期E1与完整向导明确分开 |
| 宪章 | Python/FastAPI/现Provider/结构化输出/Docker与评测原则保留；不修改宪章 |
| 覆盖 | FR34+NFR8+SC12=54项均映射；无无映射任务；不是实现覆盖率 |
| 不一致 | 主文档/合同/任务/roadmap/quickstart同步；旧审计事实作为历史保留 |

### 更新后的需求映射

| 要求 | 任务 |
|---|---|
| FR-001 | T194、T196、T198、T199、T202、T232 |
| FR-002 | T194、T198、T199 |
| FR-003 | T196、T197、T228 |
| FR-004 | T196、T197、T200、T201、T228 |
| FR-005 | T197、T200、T201、T210、T228 |
| FR-006 | T204、T205、T210、T226、T234 |
| FR-007 | T204、T206、T226、T232、T235 |
| FR-008 | T197、T204、T205、T206、T210、T226、T234、T236 |
| FR-009 | T193、T207、T208、T225、T237 |
| FR-010 | T207、T208、T213、T225 |
| FR-011 | T207、T208、T225 |
| FR-012 | T207、T209、T227、T237 |
| FR-013 | T207、T209、T227 |
| FR-014 | T200、T201、T210、T212、T213、T228 |
| FR-015 | T211、T212、T213、T215、T236、T238 |
| FR-016 | T211、T212、T213、T215、T238 |
| FR-017 | T211、T214、T215、T220、T228、T238 |
| FR-018 | T216、T218、T221、T222、T223、T232、T235 |
| FR-019 | T216、T219、T220、T223、T227、T232、T235 |
| FR-020 | T216、T220、T223、T227 |
| FR-021 | T220、T221、T223 |
| FR-022 | T216、T218、T219、T223 |
| FR-023 | T216、T217、T222、T235 |
| FR-024 | T193、T216、T217、T229 |
| FR-025 | T222、T224、T225、T227、T229、T230 |
| FR-026 | T208、T218、T219、T220、T222、T224 |
| FR-027 | T221、T232、T233、T234、T235 |
| FR-028 | T193、T220、T221、T234 |
| FR-029 | T194、T198、T199、T236、T237 |
| FR-030 | T195、T211、T213、T215、T231、T237 |
| FR-031 | T202、T204、T205、T206、T212、T226、T234、T238 |
| FR-032 | T202、T210、T220、T228、T238 |
| FR-033 | T192、T195、T203、T224、T231、T239 |
| FR-034 | T207、T209、T219、T227 |
| NFR-001 | T217 |
| NFR-002 | T209 |
| NFR-003 | T200、T201 |
| NFR-004 | T209 |
| NFR-005 | T222、T224、T229、T230 |
| NFR-006 | T222、T229、T230、T233 |
| NFR-007 | T205、T209、T212 |
| NFR-008 | T192、T211、T213、T233、T236、T239 |
| SC-001 | T223、T234、T239 |
| SC-002 | T216、T219、T223、T235、T239 |
| SC-003 | T201、T207、T209、T210、T225、T237、T239 |
| SC-004 | T194、T198、T199、T203、T231、T239 |
| SC-005 | T197、T204、T210、T226、T230、T234、T236、T239 |
| SC-006 | T211、T213、T215、T237、T238、T239 |
| SC-007 | T211、T214、T215、T220、T228、T238、T239 |
| SC-008 | T233、T234、T235、T238、T239 |
| SC-009 | T216、T217、T223、T231、T235、T239 |
| SC-010 | T198、T203、T231、T236、T237、T239 |
| SC-011 | T230、T239 |
| SC-012 | T207、T209、T227、T239 |

## Changed Files

全部变更限本Feature，14份中修订12份；audit.md保留历史事实，checklists/requirements.md保留内置自检，未将其当独立通过证据。

| 文件 | 原因 |
|---|---|
| [spec.md](spec.md) | 定点澄清FR-017/019/020/023及向导重检措辞，保留全部需求ID和故事。 |
| [plan.md](plan.md) | 无环状态/装配、Probe接纳寿命、Launcher重授权、索引接纳、早期E1和门禁。 |
| [research.md](research.md) | 同步R05/R06/R07决定，消除旧Business Ready先于装配及模糊授权描述。 |
| [data-model.md](data-model.md) | activation_validation、四层就绪、索引预览与同事务adoption审计。 |
| [contracts/settings-api.md](contracts/settings-api.md) | 重授权用户路径、Probe持续使用、就绪及索引GET/预览/确认接口。 |
| [contracts/runtime-configuration.md](contracts/runtime-configuration.md) | 同步激活接纳及历史索引受控操作责任。 |
| [quickstart.md](quickstart.md) | 可执行NoPersist路径预检、B0/B1/B2和未来聚焦验收场景。 |
| [tasks.md](tasks.md) | 保持48项/编号/全未勾选；调整7项依赖，补责任、测试与E1范围。 |
| [test-change-plan.md](test-change-plan.md) | 三层证据及F02–F06未来具体TCR覆盖，不修改测试。 |
| [roadmap.md](roadmap.md) | 仅修正A/B早期可交错的时序，不变后续路线。 |
| [checklists/readiness.md](checklists/readiness.md) | 保留原24题与复选框，追加独立证据表。 |
| [analysis-report.md](analysis-report.md) | 以本轮复审取代先前过宽结论，保存发现、准入及更新追溯表。 |

## 本轮验证与停止

只执行只读仓库/脚本/源码取证、路径预检、Markdown一致性/相对链接与任务图/54项映射检查。源码/测试/依赖/迁移/运行配置变更均为0；业务测试、构建、数据库操作和模型调用均为0。旧Feature指针、旧任务、宪章及用户.gitignore前后指纹一致；没有提交/推送。本轮到文档复审与准入说明为止。

## S0后续状态（2026-10-10）

T192 B0见audit.md/evidence/s0-b0-manifest.json，T193确认F01–F08并修订settings-api §1.2来源方法矩阵，T194资源计划见resource-plan.md，T195具体TCR见../../docs/test-change-record-local-settings.md。安全GET/HEAD缺Origin可在Token/精确Host成立下读取；存在非法Origin拒绝，所有敏感写必须合法Origin，不放宽鉴权或跨站保护。

48项ID/依赖保持，无环；当前4完成/44未完成，54项需求映射不变。旧复审24项文档证据建议通过仍是规划质量评价，非运行验收，本轮不自动勾选。旧Feature指针、T001–T191、业务/测试/运行配置未改。专属Test资源pending；B1/B2以及本轮所有动态验证not_run。S0完成立即停止，下一轮S1需用户确认和相应资源/护栏准入。
