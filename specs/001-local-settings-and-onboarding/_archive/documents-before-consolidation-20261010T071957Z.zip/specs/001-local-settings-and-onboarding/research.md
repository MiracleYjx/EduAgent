# Research: Local Settings and Onboarding

日期：2026-10-10。事实证据见 [audit.md](audit.md)，产品决定见 [spec.md](spec.md)。下述“推荐设计”是本批可审查的实施方案；尚未实施或安装依赖。

## R01 - 配置责任与持久化

**Decision**：保留 Pydantic；新增薄 ConfigService、EnvironmentProfile 和不可变 SettingsRevision，以环境目录下非敏感 JSON 为数据库外的设置事实源。凭据独立存储。UI/Launcher/Benchmark 均调用同一解析规则。
**Rationale**：数据库未知时仍要能设置数据库；把配置主表放业务 PG 会造成自举循环。既有缓存不能提供来源、原子激活与运行快照。
**Alternatives**：业务数据库配置表存在自举依赖；继续直接改 .env 无法满足密钥禁令；远程配置服务超出单机需求。
**来源**：[Pydantic settings 自定义来源与优先级](https://docs.pydantic.dev/latest/concepts/pydantic_settings/)。具体新优先级是本项目设计，不能称 Pydantic 默认已实现。

## R02 - Windows 凭据

**Decision**：推荐当前用户范围 DPAPI，标准库 ctypes 调用 Crypt32；不加 pywin32/keyring，不启用 LOCAL_MACHINE 标志。密文和引用按环境分开。
**Rationale**：契合现有 Python/EXE 用户目录和少量秘密值；避免通用后端自动选择或明文 fallback。
**Alternatives**：Credential Manager Generic Credential 同样可行；OS 管理项更便利，但系统库和外部删除需同步处理，且 blob 有 2560 字节上限。本批无需额外通用密钥框架。
**Lifecycle**：正确声明 ABI、长度，使用 UI_FORBIDDEN，LocalFree 释放输出；内存明文仅调用期存在，Python 不承诺全部字符串可靠清零。Windows 用户配置丢失、密码管理重置或密文损坏时显式重录；不承诺跨机器/用户可移植。不能防御同一 OS 用户控制的恶意进程。
**来源**：[CryptProtectData](https://learn.microsoft.com/en-us/windows/win32/api/dpapi/nf-dpapi-cryptprotectdata)、[DPAPI 示例](https://learn.microsoft.com/en-us/windows/win32/seccrypto/example-c-program-using-cryptprotectdata)、[ctypes](https://docs.python.org/3.12/library/ctypes.html)、[CREDENTIALW](https://learn.microsoft.com/en-us/windows/win32/api/wincred/ns-wincred-credentialw)、[CredWriteW](https://learn.microsoft.com/en-us/windows/win32/api/wincred/nf-wincred-credwritew)。

## R03 - Docker 凭据（用户已决定）

**Decision**：用户选择外部只读 Secret 管理；只保存批准的引用，不提供 UI 密钥写入。
**Rationale**：Docker 是开发/验证路径；不新增主密钥、加密库、可移植导出及密钥恢复体系。
**Alternatives**：加密 volume + 独立 Secret 主密钥可实现 GUI 写入，但增加关键依赖/恢复责任，本批排除。
**边界**：Compose Secret 是按服务挂载的外部输入，不等于 Swarm 加密仓库；宿主 secret 文件权限由宿主管理，不能因声明 uid/gid/mode 就假定 bind source 已隔离。不可挂 Docker socket 给网页管理宿主秘密。
**来源**：[Compose secrets](https://docs.docker.com/compose/how-tos/use-secrets/)、[service secrets](https://docs.docker.com/reference/compose-file/services/#secrets)。

## R04 - UI 选型（用户已决定 B）

| 维度 | A：Gradio 设置页 | B：最小 React 外壳 |
|---|---|---|
| 接入与复用 | 利用现有组件，但须把设置规则抽出事件 | 首次建前端工程，后端服务与今后业务 UI 可复用 |
| 维护成本 | 当前少一条构建链，迁移时重写表单 | 两个 UI 并存，设置界面迁移成本较低 |
| 无数据库时静态资源 | 须避免构造业务 Gradio 的依赖 | 构建后静态资源可由 Bootstrap 独立服务 |
| API 合同 | 容易继续走内部事件调用，仍需独立 API | 天然 API/DTO 边界 |
| Docker/EXE | 可复用现有 Gradio 收集逻辑 | 新增构建产物复制和包内路由回退验证 |
| 双 UI 复杂度 | 单 UI | 分路由、独立授权，明确“进入业务工作台”链接 |
| 全 React 迁移成本 | 设置页重复开发 | 复用路由、组件与 API 客户端；本批不迁业务页面 |

**Decision**：React + TypeScript + Vite + Ant Design + React Router；React hooks/context 管理局部表单与短期授权，原生 fetch 封装取消/错误，无新增全局状态库；OpenAPI DTO 的 TS 类型生成作构建工具（拟 openapi-typescript），不引入 Node 运行时服务。
**Rationale**：配置页数量少，查询/状态库的额外缓存语义当前无必要。任务仍列 DTO 漂移检查，不手写两份事实源。
**来源**：[Vite production build](https://vite.dev/guide/build.html)。构建后的静态目录是目标方案，不代表当前仓库已存在 frontend。

## R05 - Bootstrap 与业务生命周期

**Decision**：根 FastAPI 生命周期先建立设置服务；Business Prerequisites Ready通过后先装配业务router/Gradio，再调用原恢复钩子一次，阶段完成才产生Business Ready。依赖/目录改变重启激活；不在运行中卸载/重装 Gradio。启动恢复按原语义执行一次。
**Rationale**：当前 app 模块顶层/工厂过早强验证。分离 setup/business/provider 配置即可解除耦合，不需要重写工作流。
**Alternatives**：给必填字段填假 Key/空连接会虚构就绪；单独第二后端端口增加 UI、授权及打包复杂度。
**来源**：[FastAPI lifespan](https://fastapi.tiangolo.com/advanced/events/)。本方案由根应用统一管理资源，不能假定子应用生命周期自动被运行。

## R06 - 设置权限

**Decision**：启动 OS 用户/容器宿主管理者获取短期、单次授权码，换限定设置用途的内存 token；精确 Host/Origin、无通配 CORS，所有管理操作含 Probe 均验证 token。旧业务仍 JWT/RBAC。
**Rationale**：旧鉴权依赖 DB，自举不能依赖它；公开 GET 不能自动授予管理权限。
**Docker 差异**：主机 loopback 发布经 NAT 后 peer 未必 loopback；以部署发布检查 + capability + Host/Origin 授权，不信任 Forwarded/X-Forwarded-For。Windows listener 和 peer 均 loopback。
**来源**：[Origin](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Origin)、[Docker port publishing](https://docs.docker.com/engine/network/port-publishing/)。
**持续入口**：复用Windows Launcher所有者进程及匿名控制管道，保留“打开设置/重新授权”控制窗口；刷新、关页重开、码或会话过期均回此入口，新码登记后开页。Docker再次由宿主受限exec申请；公开HTTP无领码接口。详见plan §3，不增加常驻服务。
**取舍**：同一 OS 用户可获设置权限，不解决同账号下教师/学生保密；未来无登录模式须明确该边界。

## R07 - 能力与探测

**Decision**：统一 Registry 驱动实际工厂和界面。通用 OpenAI-compatible 文本 Adapter 为本批新增；结构化模式、图像、向量、重排分别声明并检测。规则 Reviewer 保留；Rerank 别名不冒充独立云重排 API。
**激活与持续使用**：10分钟只约束候选Probe的新鲜度；激活后保存接纳事实，不因时间流逝取消AI Ready，不自动重测收费。详见plan §2.3/§4。
**Rationale**：当前枚举和工厂不一致；供应商名不是能力证明。Probe 是单次最小合成请求，不能走业务重试/fallback 隐藏调用数。
**来源**：[DeepSeek JSON Output](https://api-docs.deepseek.com/guides/json_mode/)：json_object 仍需提示及本地 schema 校验，空输出必须保留失败。本轮未验证任何真实 Vision 模型；不锁定未经验证的可用性。

## R08 - 运行与索引兼容

**Decision**：运行首次启动生成独立非敏感快照，持久检查点保留 snapshot_id 和绑定；新配置只影响新运行。原 Prompt/Adapter/凭据缺失则明确阻塞 AI 步骤。不新增 Prefix Cache。
**Decision**：保持 vector(1024)，新增索引来源登记并检查同维度模型语义。历史来源未知保留 unknown；有向量时禁止未经证据接纳的新模型，不自动重建。
**旧运行策略**：升级接纳时记录当前 legacy 配置基线；没有快照的非终态运行继续旧恢复路径并标来源未完整记录。存在此类运行期间禁止模型/阈值/检索绑定切换，直至原运行完成或用户按原业务流程终止。不能用新配置填充历史身份。此约束不阻塞设置访问或无关配置草稿。
**Alternatives**：清全局缓存影响在途实例；恢复时用当前值混模型；仅比较维度漏掉同维度空间差异。

## R09 - 隔离与评测

**Decision**：Test 独立数据库/角色和 Redis 实例，库内随机 schema 仅作单次运行隔离；Demo 独立 Compose 项目/卷，Development 显式接纳原数据，不自动搬迁。统一资源计划先校验再运行/清理。
**Rationale**：随机 schema 不等于清理权限隔离，现有检索与评分 benchmark 默认调用策略不一致。
**变化**：普通回归和检索自检默认 Fake；真实模式必须显式选择并保留来源/费用授权。属于公开工具行为变化，未来先 TCR 再改入口。

## Constitution 评估与澄清建议

I 保留 Docker 三容器及真实业务就绪；III 保留可替换 Provider；IV 所有核心结果 JSON/Pydantic；V 真实模型结论须证据。均兼容。II 的“第一阶段 80%/20%”结合原 spec 对第一阶段=v1.0 的定义，不应量化为本次设置批次工时比例；本批范围由 D06–D08 明确决定，仍服务 AI 使用，不开展全 UI 重写。

没有发现必须修改宪章才能完成本批的条款。为防止后续误解，建议单独批准一次措辞澄清：“II 中第一阶段专指 v1.0；后续发布按获批准的阶段目标安排，仍保留 AI 业务优先和最小基础设施原则。”本轮不改 Constitution，也不把建议当新门禁。未来取消 JWT、React 全迁移与历史局部规格冲突，但它们不在 Constitution 中被固定为永久技术要求。

## 未验证项

DPAPI ABI/冻结包、Docker NAT/挂载权限、通用服务实际能力、当前全量回归、纯净机部署和 UI 实测须在 S1–S5 完成；未知不被填成通过。所有公开文档核对日期为 2026-10-10；实施时仅锁定实际兼容版本，不自动追新或替换技术路线。
