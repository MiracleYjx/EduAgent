# Test Change Plan：本批TCR前置与验证映射

本文件是规划，不是已经执行的测试变更记录。日期2026-10-10，源码基线e894581。**本轮测试源码修改0、测试执行0、付费调用0**。沿用 `docs/test-change-record-v2.md:7–23` 的框架；每个未来批次在 `docs/test-change-record-local-settings.md` 先记录具体TCR，再修改测试，不以本表替代每批记录。

## 每批必须填写的记录

标识/基线/日期；当前可观察缺口和必要性；已确认合同/未决项；具体文件和新增或修改断言；必须保留的原断言；固定输入与预期；实际Test资源/替身；实现前失败证据；实现后聚焦验证；真实运行结果/skip/warnings/清理/付费授权范围。未跑写not_run，不能预填passed；纯ImportError不能证明目标业务红灯。

## 覆盖与保留断言

| 范围 | 为什么需要新增或修改 | 覆盖/框架 | 必须保留 |
|---|---|---|---|
| 环境/配置 | 现helper默认读取当前库；来源优先级不同 | unit/settings；tests/postgres_helpers.py；配置contract | 非Test零改动，原合法输入与中文错误语义 |
| 秘密/权限 | 明文env与DB依赖鉴权不能满足Bootstrap | Windows真实DPAPI、Fake凭据、API contract、输出扫描 | 原JWT/RBAC、课程/学生归属不放宽 |
| Provider/Probe | 枚举与工厂不同，缺八类诊断 | Fake/Mock unit、Provider contract，显式真实probe | generate_structured接口、JSON/Pydantic、无静默fallback |
| 快照/索引 | 当前恢复取最新配置，缺旧向量身份 | Workflow state往返、PG重启integration、真实vector合同 | 客观题不LLM、待复核不最终化、原run/轮次、历史unknown |
| Bootstrap | 配置缺失当前阻断整个HTTP | API/生命周期/打包contract | /ready失败真实，业务初始化不被设置可达替代 |
| UI | 新PC设置流程与来源状态 | 前端组件、真实浏览器、两种尺寸 | 原Gradio业务入口仍可登录和使用 |
| Benchmark/交付 | 旧验收写临时明文env，真实调用默认不一致 | 入口contract、Fake调用计数、真实EXE/Docker | 历史结果格式及失败记录，不把selftest当质量 |
| 备份/恢复 | 新快照应随业务，秘密不应随业务 | 既有backup integration扩展 | 同集/文件引用一致，不自动覆盖用户库 |

## 原有回归与本批门槛

复用既有 `tests/contract/test_auth_api_contract.py`、`test_workflow_api_contract.py`、`test_reviews_api_contract.py`、`tests/unit/workflows/test_workflow_state.py`、`tests/integration/test_backup_restore.py` 等实际入口；实施先核对节点，禁止为任务方便伪造现有测试名。新增设置测试位置见tasks。

代码/测试变化完成后按仓库既有要求执行pytest、mypy、ruff；新前端类型/测试/构建另补。实数据库/容器/包/真实模型按影响验证，资源护栏未建好前不对当前环境跑全量。单元通过不替代真实Windows DPAPI与冻结包；真实外部模型能力未测不作通过结论。

## 测试语义变化清单

允许因明确新合同改变：缺模型密钥时Setup可以成功但业务/AI状态独立；新优先级process-env高于saved；检索评测普通模式默认Fake；新的设置权限和错误码。
不允许改变：旧业务授权、审核/组卷、分值与最终成绩、Provider结构化返回、失败非成功、历史来源unknown、只清本次资源。旧断言如需变更，逐条说明该合同变化及替代覆盖，不可简单删除失败测试。


## 基线证据分层（T192 / T203 / 后续回归）

| 层 | 何时/责任 | 可证明什么 | 不可声称什么 |
|---|---|---|---|
| B0 修改前证据 | T192，在任何源码/测试/运行配置修改前 | HEAD、完整相关差异/文件指纹、环境身份、旧回执日期及对应代码；安全可行的只读/纯单元结果 | 历史回执不能证明当前原样运行通过；未跑记not_run |
| B1 护栏后的当前基线 | T203，T196–T202之后 | 精确记录已包含哪些护栏、测试与配置变化；专属Test上命令/用例、结果、skip、哨兵和清理 | 不能称“修改前基线”，不能仅凭失败出现在B1就判既有问题 |
| B2 后续回归 | 后续每批实现与T231/T238 | 引用B1或最近可比回执、当前差异、相同输入/目标、实际结果和新增影响 | 测试/数据/环境变化未解释时不能直接判回归或质量提升 |

每层记录source_commit、working_diff/file_manifest、test_revision、配置/资源脱敏身份、UTC、命令、退出码、回执来源。需要补B0动态比较时，仅在不会触碰用户数据的隔离副本中运行经审查入口；附加护栏或测试修订必须记录，不能称未经修改的B0。没有安全方式则保留unknown并沿调用链定位，不回切用户工作区、不临时关闭护栏。

T203失败只在存在可比证据时归为既有/新增；否则“归因未定”。直接影响当前后续任务的失败先解决，独立历史问题不泛化为全批阻塞。

## 本轮复审补充的未来TCR覆盖

- F02：四层状态；前置通过但未装配仍503、首次修复须重启、原三个恢复钩子每业务进程一次；健康/诊断/初始化不重复调用；依赖短暂恢复不重装配。T216设计，T218/T219覆盖E1，T220/T223覆盖完整协调。
- F03：候选Probe超过10分钟拒激活；active/pending接纳事实不会按时间失效；未变绑定保存/普通重启/轮询零自动收费，变更目标重新验证。T207/T209/T210/T220/T223。
- F04：过期一次码、刷新/关闭重开、闲置/绝对会话到期→Launcher新码→读回已存进度；无浏览器持久Token、无公开领码、无自动重放。T216/T217/T221/T222。
- F05：证据不足/冲突/非原KB证据拒绝；预览/确认/过期/授权、接纳与摄取并发、identity和adoption同事务失败回滚、重复确认读回、原向量零改动、审计随备份。T211/T214/T220/T224/T228/T238。
- F06：E1必须完成权限、非Test拒绝、错误就绪和静态构建的聚焦验证；完整AI/Workflow/Embedding测试仍在原责任任务和T231中执行，不为了提前展示删除或放宽。


## S0 T195落地记录

已建立[首批具体TCR](../../docs/test-change-record-local-settings.md)，范围为T196–T203环境/配置/隔离基础，锁定拟新增/修改的文件、固定场景、原断言、B0/B1/B2和资源停止条件。该文件为文档，本轮未改测试；先行红灯/实现后结果全为not_run。Origin后续合同矩阵按settings-api §1.2列入后续T216前具体TCR，不提前执行。
