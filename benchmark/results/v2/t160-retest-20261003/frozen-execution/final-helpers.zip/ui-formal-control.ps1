param(
    [Parameter(Mandatory=$true)][ValidateSet('prepare','start','status','stop','plan')][string]$Mode,
    [ValidateSet('text','figure','cross')][string]$Workload='text',
    [ValidateSet('cold','warm')][string]$Temperature='cold',
    [ValidateRange(1,3)][int]$Repeat=1,
    [int]$Port=7871,
    [string]$QualityPointer,
    [string]$QualityOutput
)
$ErrorActionPreference='Stop'
$batchRoot=Split-Path -Parent $PSCommandPath
$repoRoot=Split-Path -Parent (Split-Path -Parent $batchRoot)
$sourceRoot=Join-Path $batchRoot 'source-final'
$runtimePython=Join-Path $repoRoot '.cache/e2-t157-159-20261002/runtime/Scripts/python.exe'
$launchFile=Join-Path $sourceRoot 'benchmark/t160/ui-correction/correction_ui_launch.py'
$serverFile=Join-Path $sourceRoot 'benchmark/t160/ui-correction/correction_ui_server.py'
$fixturesFile=Join-Path $batchRoot 'ui-formal-fixtures.json'
$groupKey=if($Temperature -eq 'cold'){"$Workload-cold-$Repeat"}else{"$Workload-warm"}
$outDir=Join-Path $batchRoot "ui-formal/$groupKey"
function Quote-Arguments([string[]]$Values) { return (($Values | ForEach-Object { '"'+$_.Replace('"','\"')+'"' }) -join ' ') }
function Read-Json([string]$Path) { return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json }
function Check-Owned-Worker($Record) {
    $worker=Get-CimInstance Win32_Process -Filter "ProcessId=$($Record.service_pid)"
    if($null -eq $worker){return $null}
    $normalized=$worker.CommandLine.Replace('\','/').ToLowerInvariant()
    if(-not $normalized.Contains($serverFile.Replace('\','/').ToLowerInvariant()) -or -not $normalized.Contains($outDir.Replace('\','/').ToLowerInvariant())){throw 'Worker command does not match the exact owned UI group.'}
    if($worker.CreationDate.ToUniversalTime().Ticks -ne ([datetime]$Record.service_created_at).ToUniversalTime().Ticks){throw 'Worker PID was reused; refusing to stop another process.'}
    return $worker
}
if($Mode -eq 'plan') {
    [pscustomobject]@{source=$sourceRoot;fixtures=$fixturesFile;output=$outDir;groups=12;timed_actions=24;warmup_actions=3;cloud_calls=0;sampler='one-second real worker; action window only'} | ConvertTo-Json
    exit 0
}
if($Mode -eq 'prepare') {
    if(-not $QualityPointer -or -not $QualityOutput){throw 'prepare requires --QualityPointer and --QualityOutput from this new real quality run.'}
    if(Test-Path -LiteralPath $fixturesFile){throw 'Fresh replay manifest required; old records are never replaced.'}
    $qualityManifest=Read-Json (Join-Path $QualityOutput 'manifest.json')
    if($qualityManifest.source_root.Replace('\','/').TrimEnd('/') -ne $sourceRoot.Replace('\','/').TrimEnd('/')){throw 'Formal UI requires this new source-final quality run; old first-round output is not accepted.'}
    $pointerPath=(Resolve-Path -LiteralPath $QualityPointer).Path
    if(-not $pointerPath.StartsWith($batchRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Use the new batch quality pointer.'}
    & $runtimePython -X utf8 $launchFile --repo-root $repoRoot --batch-root $batchRoot --source-root $sourceRoot --fixtures $fixturesFile --prepare-replays --quality-pointer $QualityPointer --quality-output $QualityOutput --output (Join-Path $batchRoot 'ui-formal-prepare')
    if($LASTEXITCODE -ne 0){throw "Replay preparation exited $LASTEXITCODE"}
    exit 0
}
if($Mode -eq 'start') {
    if(-not (Test-Path -LiteralPath $fixturesFile)){throw 'Prepare the 27 fresh replay records first.'}
    if(Test-Path -LiteralPath $outDir){throw 'Fresh output directory required; do not overwrite/retry a scored group.'}
    if(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue){throw 'UI port is already in use; stop the exact previous group first.'}
    New-Item -ItemType Directory -Path $outDir | Out-Null
    $launchArgs=@('-X','utf8',$launchFile,'--repo-root',$repoRoot,'--batch-root',$batchRoot,'--source-root',$sourceRoot,'--fixtures',$fixturesFile,'--workload',$Workload,'--temperature',$Temperature,'--repeat',"$Repeat",'--port',"$Port",'--output',$outDir)
    $launcher=Start-Process -FilePath $runtimePython -ArgumentList (Quote-Arguments $launchArgs) -WindowStyle Hidden -PassThru -WorkingDirectory $repoRoot -RedirectStandardOutput (Join-Path $outDir 'launcher.stdout.txt') -RedirectStandardError (Join-Path $outDir 'launcher.stderr.txt')
    $deadline=[DateTime]::UtcNow.AddSeconds(45)
    $serviceFile=Join-Path $outDir 'service.json'
    while(-not (Test-Path -LiteralPath $serviceFile)) {
        if($launcher.HasExited){throw 'Owned UI launcher exited before writing service.json.'}
        if([DateTime]::UtcNow -ge $deadline){throw 'UI service handshake pending; inspect exact group without restarting it.'}
        Start-Sleep -Milliseconds 200
    }
    $service=Read-Json $serviceFile
    $worker=Get-CimInstance Win32_Process -Filter "ProcessId=$($service.pid)"
    if($null -eq $worker){throw 'Actual UI worker is missing after handshake.'}
    $record=[pscustomobject]@{group=$groupKey;launcher_pid=$launcher.Id;service_pid=$service.pid;service_created_at=$worker.CreationDate.ToUniversalTime().ToString('o');started_at=[DateTime]::UtcNow.ToString('o');port=$Port;output=$outDir;status='started'}
    Check-Owned-Worker $record | Out-Null
    $samplerFile=Join-Path $batchRoot 'ui-formal-sampler.py'
    $samplerArgs=@('-X','utf8',$samplerFile,'--service-json',$serviceFile,'--output',$outDir,'--stop-file',(Join-Path $outDir 'stop-resource'),'--isolation-file',(Join-Path $batchRoot 'isolation.json'),'--source-root',$sourceRoot,'--launcher-pid',"$($launcher.Id)")
    $sampler=Start-Process -FilePath $runtimePython -ArgumentList (Quote-Arguments $samplerArgs) -WindowStyle Hidden -PassThru -WorkingDirectory $repoRoot -RedirectStandardOutput (Join-Path $outDir 'sampler.stdout.txt') -RedirectStandardError (Join-Path $outDir 'sampler.stderr.txt')
    $record | Add-Member -NotePropertyName sampler_launcher_pid -NotePropertyValue $sampler.Id
    $record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outDir 'control.json') -Encoding UTF8
    $deadline=[DateTime]::UtcNow.AddSeconds(35)
    $samplerReceipt=Join-Path $outDir 'ui-resource-sampler.json'
    do {
        if($sampler.HasExited){throw 'Resource sidecar exited before its sampling receipt; inspect retained stderr.'}
        if(Test-Path -LiteralPath $samplerReceipt){$receipt=Read-Json $samplerReceipt;if($receipt.status -eq 'sampling'){break}}
        if([DateTime]::UtcNow -ge $deadline){throw 'UI sampler handshake pending; do not start browser timing yet.'}
        Start-Sleep -Milliseconds 200
    } while($true)
    [pscustomobject]@{group=$groupKey;service_pid=$service.pid;sampler_pid=$receipt.sampler_pid;url="http://127.0.0.1:$Port/";output=$outDir;browser_action='Navigate/reload and wait for initial controls/page and queue to finish before target action';warm_actions=if($Temperature -eq 'warm'){'warmup then warm-1..5 using fresh instances'}else{$null}} | ConvertTo-Json
    exit 0
}
$controlFile=Join-Path $outDir 'control.json'
if(-not (Test-Path -LiteralPath $controlFile)){throw 'No owned group control receipt.'}
$control=Read-Json $controlFile
$worker=Check-Owned-Worker $control
if($Mode -eq 'status') {
    [pscustomobject]@{group=$groupKey;worker_alive=($null -ne $worker);control=$control;sampler=if(Test-Path -LiteralPath (Join-Path $outDir 'ui-resource-sampler.json')){Read-Json (Join-Path $outDir 'ui-resource-sampler.json')}else{$null}} | ConvertTo-Json -Depth 10
    exit 0
}
Set-Content -LiteralPath (Join-Path $outDir 'stop-resource') -Value 'stop' -Encoding UTF8
$deadline=[DateTime]::UtcNow.AddSeconds(30)
while(-not (Test-Path -LiteralPath (Join-Path $outDir 'ui-action-resources.json'))) {
    if([DateTime]::UtcNow -ge $deadline){throw 'Resource finalization incomplete; UI worker retained so missing data can be diagnosed.'}
    Start-Sleep -Milliseconds 200
}
if($null -ne $worker){Check-Owned-Worker $control | Out-Null;Stop-Process -Id $control.service_pid}
$control.status='stopped';$control | Add-Member -NotePropertyName stopped_at -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
$control | ConvertTo-Json | Set-Content -LiteralPath $controlFile -Encoding UTF8
[pscustomobject]@{group=$groupKey;stopped_service_pid=$control.service_pid;resource_summary=(Join-Path $outDir 'ui-action-resources.json')} | ConvertTo-Json
