"""Observe one real UI worker; action resources use only complete in-window cycles."""
from __future__ import annotations
import argparse,json,os,sys,time
from datetime import UTC,datetime,timedelta
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument("--service-json",type=Path,required=True);p.add_argument("--output",type=Path,required=True);p.add_argument("--stop-file",type=Path,required=True);p.add_argument("--isolation-file",type=Path,required=True);p.add_argument("--source-root",type=Path,required=True);p.add_argument("--launcher-pid",type=int,required=True);args=p.parse_args()
sys.path.insert(0,str(args.source_root.resolve()/"benchmark/t160"))
from resource_sampler import ResourceSampler,verified_worker_chain
service=json.loads(args.service_json.read_text(encoding="utf8"));isolation=json.loads(args.isolation_file.read_text(encoding="utf8"));out=args.output.resolve()
assert args.stop_file.resolve().parent==out and not args.stop_file.exists()
chain=verified_worker_chain(service["pid"],args.launcher_pid)
receipt={"sampler_pid":os.getpid(),"service_pid":service["pid"],"verified_worker_chain":chain,"started_at":datetime.now(UTC).isoformat(),"status":"starting","scope":"background lifetime observation; NOT action-window peaks"}
def save(): (out/"ui-resource-sampler.json").write_text(json.dumps(receipt,indent=2),encoding="utf8")
save()
sampler=ResourceSampler(pid=service["pid"],pg_container=isolation["pg_container"],redis_container=isolation["redis_container"],output_path=out/"ui-resources.jsonl",interval_seconds=1.0)
try:
 sampler.start();receipt["status"]="sampling";receipt["ready_at"]=datetime.now(UTC).isoformat();save()
 while not args.stop_file.exists():time.sleep(.2)
 sampler.sample_now();receipt["status"]="stopped_by_file"
except Exception as error:
 receipt["status"]="failed";receipt["error"]={"type":type(error).__name__,"message":str(error)}
 raise
finally:
 sampler.stop();receipt.update(ended_at=datetime.now(UTC).isoformat(),lifetime_observation=sampler.summary());save()
 (out/"ui-resource-summary.json").write_text(json.dumps(receipt,indent=2),encoding="utf8")

rows=[json.loads(line) for line in (out/"ui-resources.jsonl").read_text(encoding="utf8").splitlines() if line]
measurements=out/"browser-measurements.jsonl"
ends=[json.loads(line) for line in measurements.read_text(encoding="utf8").splitlines() if line] if measurements.exists() else []
keys=["app_working_set_bytes","postgres_container_process_rss_bytes","redis_container_process_rss_bytes","simultaneous_observed_sum_bytes"]
actions=[]
for end in ends:
 if end.get("event")!="end":continue
 start_at=datetime.fromisoformat(end["started_at"]);end_at=datetime.fromisoformat(end["ended_at"])
 selected=[]
 for row in rows:
  finish=datetime.fromisoformat(row["sampled_at"])
  begin=finish-timedelta(seconds=row["sample_completed_perf"]-row["perf_counter"])
  if row["pid"]==service["pid"] and start_at<=begin<=finish<=end_at:selected.append(row)
 actions.append({"run_id":end["run_id"],"warmup":end.get("warmup"),"service_pid":service["pid"],"started_at":end["started_at"],"ended_at":end["ended_at"],"complete_cycle_count_inside_window":len(selected),"peaks_inside_complete_cycles":{key:max((r[key] for r in selected if r.get(key) is not None and not r.get("errors")),default=None) for key in keys},"resource_budget_acceptance":None,"reason":"One-second sparse sampling cannot establish complete peaks for subsecond UI actions; missing observations remain null."})
(out/"ui-action-resources.json").write_text(json.dumps({"actions":actions,"sample_timestamp_semantics":"sampled_at is recorded at the end of actual component reads; cycle begin is derived by subtracting the recorded monotonic duration","sampling_interval_seconds":1.0,"browser_resource_scope":"not measured","lifetime_peaks_substituted_for_actions":False},indent=2),encoding="utf8")
