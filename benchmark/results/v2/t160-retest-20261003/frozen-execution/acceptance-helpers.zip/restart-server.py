"""T160 real API process, minimal Gradio test shell, no cloud calls."""
import json, os, sys, threading
from datetime import UTC, datetime
from pathlib import Path
run = Path(__file__).resolve().parent
source = run / "source-final"
sys.path.insert(0, str(source))
os.chdir(source)
import gradio as gr
import uvicorn
from backend.app.core.app import create_app
from backend.app.core.config import get_settings

with gr.Blocks() as shell:
    gr.Markdown("T160 API backend restart technical self-test")
app = create_app(settings=get_settings(), gradio_app=shell)
server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=17970, log_level="warning", access_log=False))
def stop_input():
    if sys.stdin.readline().strip() == "stop":
        server.should_exit = True
threading.Thread(target=stop_input, daemon=True).start()
number=os.environ["T160_RESTART_LAUNCH"]
assert number in {"1","2"}
(run/f"restart-worker-{number}.json").write_text(json.dumps({"pid":os.getpid(),"parent_pid":os.getppid(),"script":str(Path(__file__).resolve()),"source_root":str(source.resolve()),"started_at":datetime.now(UTC).isoformat()}),encoding="utf8")
server.run()

