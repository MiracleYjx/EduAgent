"""T160 restart technical self-test; never represents teacher annotation."""
from __future__ import annotations
import hashlib, json, os, subprocess, sys, time
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from uuid import uuid4

run = Path(__file__).resolve().parent
source = run / "source-final"
sys.path.insert(0, str(source))
os.chdir(source)
import httpx
from sqlalchemy import select
from sqlalchemy.engine import make_url
from backend.app.ai.ingestion.paper_pipeline import open_paper
from backend.app.core.config import get_settings
from backend.app.core.database import create_database_engine, create_session_factory
from backend.app.domain.enums import UserRole, PaperImportStatus, QuestionType, QuestionStatus, ExamStatus
from backend.app.models import Role, User, Course, PaperImport, ExtractedQuestion, Question, Exam, ExamParticipant
from backend.app.services.auth_service import AuthService
from backend.app.services.paper_import_service import PaperImportService
from backend.app.services.question_asset_service import QuestionAssetService
from backend.app.services.question_service import QuestionService
from backend.app.schemas.question_assets import AssetLinkRequest

def now(): return datetime.now(UTC).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
record = json.loads((run/"isolation.json").read_text())
settings = get_settings()
assert make_url(str(settings.database_url)).database == record["database"] == "eduagent_e2_acceptance_ac14a149cc18"
assert settings.storage_root.resolve() == (run/"business-files").resolve()
assert str(settings.redis_url) == f"redis://127.0.0.1:{record['redis_port']}/0"
source_receipt=json.loads((run/"source-final-receipt.json").read_text(encoding="utf8"))
assert Path(source_receipt["source_root"]).resolve()==source.resolve()
sys.path.insert(0,str(source/"benchmark/t160"))
from resource_sampler import verified_worker_chain
report = {"kind":"technical_selftest", "teacher_annotation":False, "cloud_calls":0, "source_commit":source_receipt["commit"], "started_at":now(), "application":"actual create_app, full lifespan, minimal injected Gradio test shell", "processes":[], "checks":[], "interrupted_imports":[], "passed":False}
engine = create_database_engine(settings)
factory = create_session_factory(engine)
owned_process = None
def save():
    (run/"restart-receipt.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
def start(number):
    global owned_process
    log = (run/f"restart-server-{number}.log").open("wb")
    p = subprocess.Popen([sys.executable,str(run/"restart-server.py")],cwd=source,env=os.environ.copy()|{"T160_RESTART_LAUNCH":str(number)},stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0)
    owned_process=p
    info={"number":number,"pid":None,"launcher_pid":p.pid,"started_at":now(),"server_script_sha256":sha((run/"restart-server.py").read_bytes())}
    report["processes"].append(info)
    try:
        with httpx.Client(timeout=5,trust_env=False) as client:
            deadline=time.monotonic()+90
            while time.monotonic()<deadline:
                if p.poll() is not None: raise RuntimeError("own server exited before readiness")
                try:
                    health=client.get("http://127.0.0.1:17970/health")
                    ready=client.get("http://127.0.0.1:17970/ready")
                    if health.status_code==ready.status_code==200:
                        handshake=json.loads((run/f"restart-worker-{number}.json").read_text(encoding="utf8"))
                        assert handshake["source_root"]==str(source.resolve())
                        assert handshake["script"]==str((run/"restart-server.py").resolve())
                        info["pid"]=handshake["pid"]
                        info["verified_worker_chain"]=verified_worker_chain(info["pid"],p.pid)
                        info["ready_at"]=now(); info["ready_status"]=ready.json()["status"]
                        return p,log
                except httpx.HTTPError: pass
                time.sleep(0.5)
        raise RuntimeError("own server readiness deadline")
    except:
        stop(p,log)
        raise
def terminate_actual_worker(p):
    """Windows venv launchers are not assumed to be the actual API process."""
    info=report["processes"][-1]
    handshake_file=run/f"restart-worker-{info['number']}.json"
    actual=info.get("pid")
    if actual is None and handshake_file.exists():
        handshake=json.loads(handshake_file.read_text(encoding="utf8"))
        assert handshake["script"]==str((run/"restart-server.py").resolve())
        actual=handshake["pid"]
    if actual is None:
        p.terminate()
        return
    info["forced_stop_worker_chain"]=verified_worker_chain(actual,p.pid)
    if os.name=="nt":
        import ctypes
        from ctypes import wintypes
        kernel=ctypes.WinDLL("kernel32",use_last_error=True)
        kernel.OpenProcess.argtypes=(wintypes.DWORD,wintypes.BOOL,wintypes.DWORD)
        kernel.OpenProcess.restype=wintypes.HANDLE
        kernel.TerminateProcess.argtypes=(wintypes.HANDLE,wintypes.UINT)
        kernel.TerminateProcess.restype=wintypes.BOOL
        kernel.CloseHandle.argtypes=(wintypes.HANDLE,)
        handle=kernel.OpenProcess(1,False,actual)
        if not handle: raise OSError(ctypes.get_last_error(),"Cannot stop verified API worker")
        try:
            if not kernel.TerminateProcess(handle,1):raise OSError(ctypes.get_last_error(),"Verified API worker stop failed")
        finally:kernel.CloseHandle(handle)
    else:
        import signal
        os.kill(actual,signal.SIGTERM)

def stop(p,log):
    global owned_process
    if p.poll() is None:
        assert p is owned_process
        assert p.args == [sys.executable,str(run/"restart-server.py")]
        try:
            p.stdin.write(b"stop\n");p.stdin.flush()
            p.wait(timeout=25)
        except subprocess.TimeoutExpired:
            terminate_actual_worker(p);p.wait(timeout=15)
            report["processes"][-1]["forced_stop"]=True
        finally:
            if p.stdin: p.stdin.close()
    report["processes"][-1]["stopped_at"]=now()
    report["processes"][-1]["exit_code"]=p.returncode
    log.close()
    owned_process=None

try:
    with factory() as session:
        suffix=uuid4().hex[:12]
        roles={}
        for role in (UserRole.TEACHER,UserRole.STUDENT):
            roles[role]=session.scalar(select(Role).where(Role.name==role))
            if roles[role] is None:
                roles[role]=Role(name=role);session.add(roles[role])
        teacher=User(username="restart_fixture_teacher_"+suffix,email=suffix+"-teacher@fixture.invalid",password_hash="synthetic-fixture-no-password",is_active=True)
        student=User(username="restart_fixture_student_"+suffix,email=suffix+"-student@fixture.invalid",password_hash="synthetic-fixture-no-password",is_active=True)
        teacher.roles.append(roles[UserRole.TEACHER]);student.roles.append(roles[UserRole.STUDENT])
        session.add_all([teacher,student]);session.flush()
        course=Course(name="T160 restart technical selftest "+suffix,created_by=teacher.id)
        session.add(course);session.commit()
        auth=AuthService(session,secret_key=settings.JWT_SECRET_KEY.get_secret_value())
        tokens={"teacher":auth.issue_access_token(teacher),"student":auth.issue_access_token(student)}
        data=(source/"benchmark/corpus/v2-draft-20261001/inputs/paper_scan.pdf").read_bytes()
        service=PaperImportService(session,root=settings.storage_root)
        main=service.upload(course.id,filename="paper_scan.pdf",content=data,actor_id=teacher.id)
        imp=session.get(PaperImport,main.id)
        with open_paper(data) as paper:
            imp.status=PaperImportStatus.PARSING;imp.page_count=paper.page_count;session.commit()
            rendered=next(paper.pages())
        assets=QuestionAssetService(session,root=settings.storage_root)
        page=assets.create_source_page(imp.id,page_number=1,content=rendered.png,actor_id=teacher.id)
        imp.status=PaperImportStatus.PENDING_REVIEW
        extracted=ExtractedQuestion(paper_import_id=imp.id,source_page_ids=[str(page.id)],extracted_by="TEXT",status="Pending Correction",order_index=1,content="TECHNICAL_SELFTEST manually seeded; no extraction/teacher quality claim",assets=[])
        session.add(extracted);session.commit()
        bounds={"bbox":[100,100,300,300]}
        staged=assets.create_staged(extracted.id,AssetLinkRequest(file_id="p_"+page.id.hex,source_page_id=page.id,asset_type="diagram",region=bounds),actor_id=teacher.id)
        qview=QuestionService(session).create_question(course.id,"SHORT_ANSWER","TECHNICAL_SELFTEST permission fixture",reference_answer="fixture",scoring_rubric="fixture",score=Decimal("2"),created_by=teacher.id)
        q=session.get(Question,qview.id if not isinstance(qview.id,str) else __import__("uuid").UUID(qview.id))
        visible=assets.link_question(q.id,AssetLinkRequest(file_id="p_"+page.id.hex,source_page_id=page.id,asset_type="diagram",region=bounds,student_visible=True),actor_id=teacher.id)
        hidden=assets.link_question(q.id,AssetLinkRequest(file_id="p_"+page.id.hex,source_page_id=page.id,asset_type="diagram",region={"bbox":[350,350,550,550]}),actor_id=teacher.id)
        full=assets.link_question(q.id,AssetLinkRequest(file_id="p_"+page.id.hex,source_page_id=page.id,asset_type="figure"),actor_id=teacher.id)
        q.status=QuestionStatus.APPROVED
        exam=Exam(course_id=course.id,created_by=teacher.id,title="T160 restart permission fixture",status=ExamStatus.PUBLISHED,questions=[q])
        session.add(exam);session.flush()
        session.add(ExamParticipant(exam_id=exam.id,student_id=student.id));session.commit()
        file_ids={"original":"d_"+main.document_id.hex,"page":"p_"+page.id.hex,"staged":staged.file_id,"visible":visible.file_id,"hidden":hidden.file_id,"full_page_asset":full.file_id}
        report["fixtures"]={"teacher_id":str(teacher.id),"student_id":str(student.id),"course_id":str(course.id),"paper_import_id":str(imp.id),"source_page_id":str(page.id),"extracted_question_id":str(extracted.id),"question_id":str(q.id),"exam_id":str(exam.id),"file_ids":file_ids,"source_pdf_sha256":sha(data),"source_fixture":"paper_scan.pdf","seeded_structured_text_is_quality_truth":False}
        # Real lifespan must classify all inherited unfinished stages, not recover them as success.
        for state in ("Uploaded","Parsing","Extracting"):
            interrupted=service.upload(course.id,filename="interrupted-"+state+".pdf",content=data,actor_id=teacher.id)
            entry=session.get(PaperImport,interrupted.id);entry.status=PaperImportStatus(state);session.commit()
            report["interrupted_imports"].append({"id":str(entry.id),"before":state,"original_file_id":"d_"+entry.document_id.hex})
        # Retain a new unfinished import before the second launch to prove restart-time recovery again.
    baseline={}
    for iteration in (1,2):
        p,log=start(iteration)
        try:
            with httpx.Client(base_url="http://127.0.0.1:17970",timeout=15,trust_env=False) as client:
                headers={name:{"Authorization":"Bearer "+token} for name,token in tokens.items()}
                for name,fid in file_ids.items():
                    response=client.get("/api/files/"+fid,headers=headers["teacher"])
                    assert response.status_code==200,(name,response.status_code)
                    fact={"iteration":iteration,"actor":"teacher_fixture","resource":name,"file_id":fid,"status":response.status_code,"bytes":len(response.content),"sha256":sha(response.content)}
                    if iteration==1: baseline[name]=(fact["bytes"],fact["sha256"])
                    else: assert baseline[name]==(fact["bytes"],fact["sha256"]);fact["same_bytes_after_restart"]=True
                    report["checks"].append(fact)
                    student_result=client.get("/api/files/"+fid,headers=headers["student"])
                    expected=200 if name=="visible" else 403
                    assert student_result.status_code==expected,(name,student_result.status_code)
                    sfact={"iteration":iteration,"actor":"student_fixture","resource":name,"status":student_result.status_code}
                    if expected==200:
                        assert sha(student_result.content)==fact["sha256"]
                        sfact["same_as_teacher_bytes"]=True
                    else:
                        body=student_result.json()
                        sfact["error_code"]=(body.get("detail") or {}).get("code") if isinstance(body.get("detail"),dict) else "HTTP_FORBIDDEN"
                    report["checks"].append(sfact)
                for actor in ("teacher","student"):
                    response=client.get(f"/api/questions/{q.id}/assets",headers=headers[actor])
                    assert response.status_code==200
                    ids=[entry["id"] for entry in response.json()]
                    assert set(ids)==({str(visible.id),str(hidden.id),str(full.id)} if actor=="teacher" else {str(visible.id)})
                    report["checks"].append({"iteration":iteration,"actor":actor+"_fixture","resource":"formal_asset_listing","status":200,"asset_ids":ids})
                response=client.get("/api/paper-imports/"+str(imp.id),headers=headers["teacher"])
                assert response.status_code==200
                payload=response.json()
                assert payload["status"]=="Pending Review" and payload["original_file_id"]==file_ids["original"] and payload["pages"][0]["file_id"]==file_ids["page"]
                assert payload["questions"][0]["assets"][0]["file_id"]==file_ids["staged"]
                report["checks"].append({"iteration":iteration,"resource":"paper_import_detail","status":200,"identity_and_file_refs_preserved":True})
                for entry in report["interrupted_imports"]:
                    response=client.get("/api/paper-imports/"+entry["id"],headers=headers["teacher"])
                    payload=response.json()
                    assert response.status_code==200 and payload["status"]=="Failed" and payload["error_code"]=="PAPER_INTERRUPTED"
                    original=client.get("/api/files/"+entry["original_file_id"],headers=headers["teacher"])
                    assert original.status_code==200 and sha(original.content)==sha(data)
                    entry["after_launch_"+str(iteration)]={"status":payload["status"],"error_code":payload["error_code"],"source_retained_sha256":sha(original.content)}
        finally: stop(p,log)
        if iteration==1:
            with factory() as session:
                new=PaperImportService(session,root=settings.storage_root).upload(course.id,filename="interrupted-before-second.pdf",content=data,actor_id=teacher.id)
                item=session.get(PaperImport,new.id);item.status=PaperImportStatus.EXTRACTING;session.commit()
                report["interrupted_imports"].append({"id":str(item.id),"before":"Extracting","created_between_launches":True,"original_file_id":"d_"+item.document_id.hex})
    assert report["processes"][0]["pid"]!=report["processes"][1]["pid"]
    report["passed"]=True
    report["completed_at"]=now()
except Exception as exc:
    report["error"]={"type":type(exc).__name__,"message":str(exc)[:300]}
    raise
finally:
    if owned_process is not None:
        terminate_actual_worker(owned_process);owned_process.wait(timeout=15)
    engine.dispose()
    save()
print(json.dumps({"passed":report["passed"],"process_pids":[r["pid"] for r in report["processes"]],"http_checks":len(report["checks"]),"interrupted_recovery_records":len(report["interrupted_imports"]),"receipt":str(run/"restart-receipt.json")}),flush=True)

