"""Read-only T160 evidence aggregation; writes a fresh derived report only."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

CASES = ("IMP-TEXT", "IMP-SCAN", "IMP-IMAGE", "IMP-MIXED", "IMP-CROSS")
FIELDS = (
    "question_number",
    "order_index",
    "source_page_numbers",
    "question_type",
    "content",
    "options",
    "reference_answer",
    "analysis",
    "score",
    "scoring_rubric",
    "knowledge_points",
    "source_regions",
    "assets",
)
STAGES = ("automatic", "assisted_corrected")
LIMITS = {
    "app_working_set_bytes": 4_000_000_000,
    "postgres_container_process_rss_bytes": 1_500_000_000,
    "redis_container_process_rss_bytes": 512_000_000,
    "simultaneous_observed_sum_bytes": 6_000_000_000,
}


def all_known(values):
    values = list(values)
    return False if False in values else (None if None in values else all(values))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo-root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    parser.add_argument("--evidence-root", type=Path)
    parser.add_argument("--quality-root", type=Path)
    parser.add_argument("--performance-root", type=Path)
    parser.add_argument("--ui-root", type=Path)
    parser.add_argument("--annotations", type=Path)
    parser.add_argument("--fault-receipt", type=Path)
    parser.add_argument("--restart-receipt", type=Path)
    parser.add_argument("--junit", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    repo = args.repo_root.resolve()
    root = (
        args.evidence_root or repo / "benchmark/results/v2/t160-retest-20261003"
    ).resolve()
    qroot = (args.quality_root or root / "quality").resolve()
    proot = (args.performance_root or root / "import-performance").resolve()
    uroot = (args.ui_root or root / "ui-correction-summary").resolve()
    annotations = (
        args.annotations
        or repo / "benchmark/corpus/t160-assisted-20261003/annotations.draft.json"
    ).resolve()
    output = (args.output or root / "acceptance-summary.json").resolve()
    if output.exists():
        raise ValueError(
            "Derived output already exists; preserve it and choose a fresh report filename"
        )
    if not (
        output.is_relative_to(repo / ".cache")
        or output.is_relative_to(repo / "benchmark/results")
    ):
        raise ValueError(
            "Derived output must remain in this workspace cache or benchmark/results"
        )
    sources, missing, errors = {}, [], []

    def remember(path):
        raw = path.read_bytes()
        sources[str(path)] = {
            "path": str(path),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
        }
        return raw

    def read(path, default=None, required=True):
        path = Path(path).resolve()
        if not path.exists():
            if required:
                missing.append(str(path))
            return default
        try:
            return json.loads(remember(path).decode("utf-8-sig"))
        except (UnicodeError, json.JSONDecodeError) as exc:
            errors.append({"path": str(path), "error": type(exc).__name__})
            return default

    labels = read(annotations, {})
    if (
        labels.get("status") != "user_confirmed_ai_assisted"
        or labels.get("is_independent_teacher_truth") is not False
    ):
        raise ValueError(
            "Expected the user-confirmed AI-assisted reference, never independent teacher truth"
        )
    entries = {e["case_id"]: e["labels"]["questions"] for e in labels["entries"]}
    if set(entries) != set(CASES) or sum(map(len, entries.values())) != 16:
        raise ValueError(
            "This approved protocol requires exactly five cases and sixteen reference questions"
        )
    planned_quality = {(case, repeat) for case in CASES for repeat in range(1, 4)}
    manifest = read(qroot / "manifest.json", {})
    qsummary = read(qroot / "summary.json", {})
    if (
        manifest
        and manifest.get("annotation_sha256") != sources[str(annotations)]["sha256"]
    ):
        errors.append(
            {"stage": "quality", "error": "reference_sha_does_not_match_manifest"}
        )
    reports = []
    for path in sorted(qroot.glob("runs/*/result.json")):
        result = read(path)
        if result is not None:
            reports.append(result)
    report_groups = {}
    for result in reports:
        key = (result["case_id"], result["repeat_index"])
        report_groups.setdefault(key, []).append(result)
    ambiguous_quality = [list(k) for k, v in report_groups.items() if len(v) != 1]
    unexpected_quality = [list(k) for k in report_groups if k not in planned_quality]

    def recorded_quality_attempt(report):
        return bool(report.get("started_at") and report.get("completed_at")) and (
            report.get("automatic_status") in {"Pending Review", "Failed"}
            or bool(report.get("runner_error"))
        )

    def recorded_quality_failure(report):
        return recorded_quality_attempt(report) and (
            report.get("automatic_status") == "Failed"
            or bool(report.get("runner_error"))
        )

    quality_complete = (
        len(reports) == 15
        and set(report_groups) == planned_quality
        and not ambiguous_quality
        and all(recorded_quality_attempt(report) for report in reports)
    )
    if qsummary and qsummary.get("attempted") != len(reports):
        errors.append({"stage": "quality", "error": "summary_result_count_mismatch"})
    metric_rows = []
    mpath = qroot / "metrics.csv"
    if mpath.exists():
        metric_rows = list(
            csv.DictReader(remember(mpath).decode("utf-8-sig").splitlines())
        )
    else:
        missing.append(str(mpath))
    indexed_metrics = {}
    for row in metric_rows:
        try:
            field = row["metric"].removesuffix("_assisted_reference_match")
            key = (row["case_id"], int(row["repeat_index"]), row["stage"], field)
            indexed_metrics.setdefault(key, []).append(row)
        except (KeyError, ValueError) as exc:
            errors.append({"stage": "quality_metrics", "error": type(exc).__name__})
    field_totals = []
    for stage in STAGES:
        for field in FIELDS:
            denominator, numerator, unknown, observed_slots = 0, 0, 0, 0
            explicit_failure_zero_slots = []
            for case, repeat in sorted(planned_quality):
                expected = sum(
                    q.get("field_states", {}).get(field) != "unknown"
                    for q in entries[case]
                )
                denominator += expected
                unknown += len(entries[case]) - expected
                rows = indexed_metrics.get((case, repeat, stage, field), [])
                report_group = report_groups.get((case, repeat), [])
                explicit_failure = len(report_group) == 1 and recorded_quality_failure(
                    report_group[0]
                )
                if len(rows) == 1:
                    row = rows[0]
                    num, den = int(row["numerator"]), int(row["denominator"])
                    comparison_rows = (
                        report_group[0].get(stage + "_comparison", {}).get("fields", [])
                        if len(report_group) == 1
                        else []
                    )
                    actual_fields = [
                        item for item in comparison_rows if item.get("field") == field
                    ]
                    expected_ids = {q["question_identity"] for q in entries[case]}
                    field_evidence_complete = (
                        len(actual_fields) == len(expected_ids)
                        and {
                            item.get("reference_question_identity")
                            for item in actual_fields
                        }
                        == expected_ids
                        and all(
                            item.get("stage") == stage
                            and item.get("case_id") == case
                            and item.get("repeat_index") == repeat
                            for item in actual_fields
                        )
                        and sum(item.get("evaluable") is True for item in actual_fields)
                        == den
                        and sum(
                            item.get("evaluable") is True
                            and item.get("correct") is True
                            for item in actual_fields
                        )
                        == num
                    )
                    if (
                        explicit_failure
                        and not actual_fields
                        and num == 0
                        and den == expected
                    ):
                        # A recorded failed attempt has no field output; keep its fixed denominator.
                        field_evidence_complete = True
                        explicit_failure_zero_slots.append([case, repeat])
                    if (
                        den != expected
                        or not 0 <= num <= den
                        or not field_evidence_complete
                    ):
                        errors.append(
                            {
                                "stage": stage,
                                "case": case,
                                "repeat": repeat,
                                "field": field,
                                "error": "metric_reference_denominator_or_numerator_invalid",
                            }
                        )
                    else:
                        numerator += num
                        observed_slots += 1
                elif not rows and explicit_failure:
                    # This is derived zero credit from an actual failure receipt, not missing evidence.
                    observed_slots += 1
                    explicit_failure_zero_slots.append([case, repeat])
                elif len(rows) > 1:
                    errors.append(
                        {
                            "stage": stage,
                            "case": case,
                            "repeat": repeat,
                            "field": field,
                            "error": "duplicate_metric_slot",
                        }
                    )
            field_totals.append(
                {
                    "stage": stage,
                    "field": field,
                    "numerator": numerator if observed_slots else None,
                    "denominator": denominator,
                    "planned_reference_questions": 48,
                    "unknown_excluded": unknown,
                    "observed_run_slots": observed_slots,
                    "explicit_failure_zero_slots": explicit_failure_zero_slots,
                    "planned_run_slots": 15,
                    "complete": observed_slots == 15,
                    "value": (
                        numerator / denominator
                        if denominator and observed_slots == 15
                        else None
                    ),
                }
            )
    identities = []
    for stage in STAGES:
        value, observed = 0, 0
        failed_identity_slots = []
        for key in sorted(planned_quality):
            group = report_groups.get(key, [])
            if len(group) == 1:
                comparison = group[0].get(stage + "_comparison")
                if comparison is not None:
                    value += comparison["matched_identities"]
                    observed += 1
                elif recorded_quality_failure(group[0]):
                    observed += 1
                    failed_identity_slots.append(list(key))
        identities.append(
            {
                "stage": stage,
                "numerator": value if observed else None,
                "denominator": 48,
                "observed_run_slots": observed,
                "explicit_failure_zero_slots": failed_identity_slots,
                "complete": observed == 15,
            }
        )
    quality_resource_windows = []
    for report in reports:
        resource = report.get("resource_summary", {})
        observed_peaks = {key: resource.get("peaks", {}).get(key) for key in LIMITS}
        complete_window = resource.get(
            "complete_at_requested_sampling_resolution"
        ) is True and all(value is not None for value in observed_peaks.values())
        pages = report.get("automatic_snapshot", {}).get("pages")
        quality_resource_windows.append(
            {
                "run_id": report["run_id"],
                "case_id": report["case_id"],
                "repeat_index": report["repeat_index"],
                "source_result_ref": str(
                    qroot / "runs" / report["run_id"] / "result.json"
                ),
                "resource_samples_ref": report.get("resource_samples_ref"),
                "actual_ocr_pages": (
                    sum(page.get("ocr_text") is not None for page in pages)
                    if pages is not None
                    else None
                ),
                "sample_count": resource.get("sample_count"),
                "observed_sampling_span_seconds": resource.get(
                    "observed_sampling_span_seconds"
                ),
                "window_duration_seconds": resource.get("window_duration_seconds"),
                "requested_interval_seconds": resource.get(
                    "requested_interval_seconds"
                ),
                "complete_at_requested_sampling_resolution": complete_window,
                "source_complete_flag": resource.get(
                    "complete_at_requested_sampling_resolution"
                ),
                "observed_sampled_peaks_bytes": observed_peaks,
                "budget_valid_window_peaks_bytes": (
                    observed_peaks if complete_window else {key: None for key in LIMITS}
                ),
                "budget_pass": (
                    all(observed_peaks[key] <= limit for key, limit in LIMITS.items())
                    if complete_window
                    else None
                ),
                "scope": resource.get("scope"),
                "limitation": (
                    None
                    if complete_window
                    else "Incomplete actual window: observations are retained, but no whole-window budget conclusion or replacement peak is inferred."
                ),
            }
        )
    quality_resource_groups = []
    for case in CASES:
        windows = [row for row in quality_resource_windows if row["case_id"] == case]
        complete_windows = [
            row for row in windows if row["complete_at_requested_sampling_resolution"]
        ]

        def maximum_observed(group):
            return {
                key: max(
                    (
                        row["observed_sampled_peaks_bytes"][key]
                        for row in group
                        if row["observed_sampled_peaks_bytes"][key] is not None
                    ),
                    default=None,
                )
                for key in LIMITS
            }

        quality_resource_groups.append(
            {
                "case_id": case,
                "planned_windows": 3,
                "observed_windows": len(windows),
                "complete_windows": len(complete_windows),
                "incomplete_windows": len(windows) - len(complete_windows),
                "observed_sampled_peaks_bytes": maximum_observed(windows),
                "peaks_across_complete_windows_bytes": maximum_observed(
                    complete_windows
                ),
                "complete_window_budget_pass": (
                    all(row["budget_pass"] for row in complete_windows)
                    if complete_windows
                    else None
                ),
                "all_planned_windows_budget_pass": (
                    all(row["budget_pass"] for row in windows)
                    if len(complete_windows) == 3
                    else None
                ),
                "group_peak_is_not_a_replacement_for_any_missing_window": True,
            }
        )
    quality_resource_observation = {
        "planned_windows": 15,
        "observed_windows": len(quality_resource_windows),
        "complete_windows": sum(
            row["complete_at_requested_sampling_resolution"]
            for row in quality_resource_windows
        ),
        "incomplete_run_ids": [
            row["run_id"]
            for row in quality_resource_windows
            if not row["complete_at_requested_sampling_resolution"]
        ],
        "by_case": quality_resource_groups,
        "windows": quality_resource_windows,
        "limits_bytes": LIMITS,
        "additional_acceptance_gate": False,
        "scope": "Actual quality import windows include scanned/image/mixed OCR when page evidence records OCR. Each simultaneous sum is the maximum of real within-sample component sums, never a sum of independent component maxima. Group maxima describe observations only; incomplete windows retain null budget conclusions.",
    }
    perf_summary = read(proot / "summary.json", {})
    perf_records = [read(p) for p in sorted(proot.glob("*/runs/*.json"))]
    perf_records = [r for r in perf_records if r is not None]
    planned_perf = {
        (case, mode, n)
        for case in ("paper_text", "workload_10_pages", "workload_50_pages")
        for mode, count in (("cold", 3), ("warm", 5), ("warmup", 1))
        for n in range(1, count + 1)
    }
    perf_groups = {}
    for row in perf_records:
        perf_groups.setdefault(
            (row["case"], row["mode"], row["repetition"]), []
        ).append(row)
    duplicate_perf = [list(k) for k, v in perf_groups.items() if len(v) != 1]
    perf_complete = (
        len(perf_records) == 27
        and set(perf_groups) == planned_perf
        and not duplicate_perf
    )
    measured = [
        v[0]
        for k, v in perf_groups.items()
        if k in planned_perf and k[1] != "warmup" and len(v) == 1
    ]

    def success(row):
        return (
            row.get("business_success") is True
            and row.get("status") == "Pending Review"
            and "completed_at" in row
        )

    def target(row):
        seconds = row.get("terminal_elapsed_seconds")
        return success(row) and isinstance(seconds, (float, int)) and 0 <= seconds < 300

    fifty = [r for r in measured if r["case"] == "workload_50_pages"]
    unaffected = [
        r for r in measured if r["case"] in {"paper_text", "workload_10_pages"}
    ]
    unaffected_1_and_10_page_gate = (
        len(unaffected) == 16 and all(target(row) for row in unaffected)
        if unaffected
        else None
    )
    resource_complete = len(measured) == 24 and all(
        r.get("resources", {}).get("complete_at_requested_sampling_resolution") is True
        for r in measured
    )
    peaks = {
        k: max(
            (
                r.get("resources", {}).get("peaks", {}).get(k)
                for r in measured
                if r.get("resources", {}).get("peaks", {}).get(k) is not None
            ),
            default=None,
        )
        for k in LIMITS
    }
    memory_gate = (
        all(peaks[k] is not None and peaks[k] <= lim for k, lim in LIMITS.items())
        if resource_complete
        else None
    )
    fifty_gate = (
        len(fifty) == 8 and sum(target(r) for r in fifty) >= 6 if fifty else None
    )
    strict_import = (
        len(measured) == 24 and all(target(r) for r in measured) if measured else None
    )
    if perf_summary and perf_summary.get("observed_total") != len(perf_records):
        errors.append(
            {"stage": "performance", "error": "summary_result_count_mismatch"}
        )
    app_peak_observations = []
    for row in quality_resource_windows:
        value = row["observed_sampled_peaks_bytes"]["app_working_set_bytes"]
        if value is not None:
            app_peak_observations.append(
                {
                    "phase": "quality",
                    "case_id": row["case_id"],
                    "run_id": row["run_id"],
                    "repeat_index": row["repeat_index"],
                    "bytes": value,
                    "mib": value / 1048576,
                    "window_complete": row["complete_at_requested_sampling_resolution"],
                    "source_result_ref": row["source_result_ref"],
                }
            )
    performance_ocr_observations = []
    for row in perf_records:
        resource = row.get("resources", {})
        value = resource.get("peaks", {}).get("app_working_set_bytes")
        pages = row.get("persisted_output_fields", {}).get("pages")
        performance_ocr_observations.append(
            {
                "case": row["case"],
                "mode": row["mode"],
                "repeat_index": row["repetition"],
                "actual_ocr_pages": (
                    sum(page.get("ocr_text") is not None for page in pages)
                    if pages is not None
                    else None
                ),
            }
        )
        if value is not None:
            app_peak_observations.append(
                {
                    "phase": "import_performance",
                    "case_id": row["case"],
                    "mode": row["mode"],
                    "repeat_index": row["repetition"],
                    "bytes": value,
                    "mib": value / 1048576,
                    "window_complete": resource.get(
                        "complete_at_requested_sampling_resolution"
                    ),
                    "source_result_ref": next(
                        (
                            path
                            for path in sources
                            if Path(path).parent.name == "runs"
                            and Path(path).name
                            == f"{row['mode']}-{row['repetition']}.json"
                            and Path(path).parent.parent.name.startswith(
                                row["case"] + "-"
                            )
                        ),
                        None,
                    ),
                }
            )
    overall_observed_app_peak = max(
        app_peak_observations, key=lambda row: row["bytes"], default=None
    )
    ui_summary = read(uroot / "summary.json", {})
    ui_attempts = read(uroot / "attempts.json", [])
    ui_ids = Counter(r["run_id"] for r in ui_attempts)
    planned_ui = {
        f"{kind}-cold-{n}" for kind in ("text", "figure", "cross") for n in range(1, 4)
    }
    planned_ui |= {
        f"{kind}-warm-{n}" for kind in ("text", "figure", "cross") for n in range(1, 6)
    }
    planned_ui |= {f"{kind}-warmup" for kind in ("text", "figure", "cross")}
    ui_complete = (
        len(ui_attempts) == 27
        and set(ui_ids) == planned_ui
        and all(v == 1 for v in ui_ids.values())
    )
    timed_ui = [
        r for r in ui_attempts if not r.get("warmup") and r["run_id"] in planned_ui
    ]
    ui_good = sum(
        r.get("status") == "success"
        and isinstance(r.get("elapsed_ms"), (int, float))
        and 0 <= r["elapsed_ms"] < 500
        for r in timed_ui
    )
    ui_gate = (
        ui_complete and len(timed_ui) == 24 and ui_good >= 20 if ui_attempts else None
    )
    strict_ui = (
        ui_complete and len(timed_ui) == 24 and ui_good == 24 if ui_attempts else None
    )
    if ui_summary and (
        ui_summary.get("attempted_timed") != len(timed_ui)
        or ui_summary.get("timed_below_500_ms") != ui_good
    ):
        errors.append(
            {"stage": "ui", "error": "summary_attempt_count_or_target_mismatch"}
        )
    fault = read(args.fault_receipt or root / "technical/fault-cases/summary.json", {})
    restart = read(args.restart_receipt or root / "technical/restart-receipt.json", {})
    expected_faults = {
        "IMP-DAMAGED": ("Upload Rejected", "PAPER_PARSE_FAILED"),
        "IMP-OVERLIMIT": ("Upload Rejected", "PAPER_TOO_MANY_PAGES"),
        "IMP-OCR-OFF": ("Failed", "OCR_PROVIDER_NOT_READY"),
        "IMP-OCR-FAIL": ("Failed", "PAPER_OCR_FAILED"),
    }
    fault_cases = fault.get("cases", [])
    fault_gate = (
        fault.get("passed") is True
        and len(fault_cases) == 4
        and {row.get("case") for row in fault_cases} == set(expected_faults)
        and all(
            row.get("passed") is True
            and (row.get("status"), row.get("error_code"))
            == expected_faults[row["case"]]
            for row in fault_cases
        )
        and fault.get("provider_boundary_entries") == 0
        and fault.get("http_requests") == 0
        if fault
        else None
    )
    restart_gate = (
        restart.get("passed") is True
        and len(restart.get("processes", [])) == 2
        and all(row.get("exit_code") == 0 for row in restart["processes"])
        and bool(restart.get("checks"))
        and bool(restart.get("interrupted_imports"))
        if restart
        else None
    )
    junit = []
    for path in args.junit:
        path = path.resolve()
        if not path.exists():
            missing.append(str(path))
            continue
        xml = ET.fromstring(remember(path))
        suites = [xml] if xml.tag == "testsuite" else list(xml.iter("testsuite"))
        counts = {
            k: sum(int(s.get(k, 0)) for s in suites)
            for k in ("tests", "failures", "errors", "skipped")
        }
        junit.append(
            {
                "path": str(path),
                **counts,
                "passed": counts["tests"] > 0
                and counts["failures"] == counts["errors"] == 0,
            }
        )
    if not args.junit:
        missing.append("explicit --junit validation receipt selection not provided")
    technical_gate = all_known(
        [
            fault_gate,
            restart_gate,
            all(r["passed"] for r in junit) if junit else None,
        ]
    )
    calls, requested, response_models, usages = 0, set(), set(), []
    for report in reports:
        calls += report.get("actual_http_attempts", 0)
        for http in report.get("http_attempts", []):
            if http.get("request", {}).get("model"):
                requested.add(http["request"]["model"])
            if http.get("actual_response_model"):
                response_models.add(http["actual_response_model"])
            if http.get("usage"):
                usages.append(http["usage"])
    for report in perf_records:
        calls += report.get(
            "actual_request_attempt_count", len(report.get("http_requests", []))
        )
        requested.update(report.get("requested_models", []))
        response_models.update(report.get("response_models", []))
        for call in report.get("llm_calls", []):
            for attempt in call.get("attempts", []):
                if attempt.get("usage"):
                    usages.append(attempt["usage"])
    token_totals = {
        k: sum(u[k] for u in usages if isinstance(u.get(k), int)) if usages else None
        for k in ("prompt_tokens", "completion_tokens", "total_tokens")
    }
    quality_protocol_gate = (
        quality_complete
        and all(r["complete"] for r in field_totals)
        and all(r["complete"] for r in identities)
        if reports
        else None
    )
    quality_all_pending_review_observation = (
        quality_complete
        and all(
            row.get("automatic_status") == "Pending Review"
            and "runner_error" not in row
            for row in reports
        )
        if reports
        else None
    )
    protocol_gate = all_known(
        [
            quality_protocol_gate,
            perf_complete if perf_records else None,
            ui_complete if ui_attempts else None,
        ]
    )
    result = {
        "task_id": "T160 retest",
        "generated_at": datetime.now(UTC).isoformat(),
        "aggregation_status": (
            "incomplete_evidence" if missing or errors else "complete_evidence"
        ),
        "source_commits_observed": sorted(
            {
                str(value)
                for value in (
                    manifest.get("source_commit"),
                    fault.get("source_commit"),
                    restart.get("source_commit"),
                    *(row.get("source_commit") for row in perf_records),
                )
                if value
            }
        ),
        "source_evidence_modified": False,
        "task_checkbox_not_written": True,
        "reference_origin": "user_confirmed_ai_assisted",
        "independent_teacher_labeled_cases": 0,
        "reference": {
            "annotation_version": labels["annotation_version"],
            "sha256": sources[str(annotations)]["sha256"],
            "author_kind": labels.get("author_kind"),
            "author_name": labels.get("author_name"),
            "human_confirmation": labels.get("user_review_confirmation"),
            "independent_teacher_truth": False,
        },
        "fixed_denominators": {
            "quality_question_instances": 48,
            "quality_imports": 15,
            "import_timed": 24,
            "import_warmups": 3,
            "ui_timed": 24,
            "ui_warmups": 3,
            "fifty_page_timed": 8,
        },
        "quality": {
            "attempted": len(reports),
            "pending_review": sum(
                r.get("automatic_status") == "Pending Review" for r in reports
            ),
            "failed": sum(r.get("automatic_status") == "Failed" for r in reports),
            "runner_errors": sum("runner_error" in r for r in reports),
            "protocol_complete": quality_protocol_gate,
            "all_imports_pending_review_observation": quality_all_pending_review_observation,
            "evidence_completeness_semantics": "All 15 planned attempts have a completed result with a terminal business status or explicit runner error. Each comparison has verifiable fields or records zero credit from the actual failed attempt; failed slots retain the fixed 48-question denominator. This is protocol completeness, not a quality success threshold.",
            "missing_slots": [
                list(k) for k in sorted(planned_quality - set(report_groups))
            ],
            "duplicate_slots": ambiguous_quality,
            "unexpected_slots": unexpected_quality,
            "identities": identities,
            "fields": field_totals,
            "quality_threshold": None,
            "quality_acceptance": "not_claimed",
            "resource_observation": quality_resource_observation,
        },
        "import_performance": {
            "observed": len(perf_records),
            "timed_observed": len(measured),
            "ocr_observations": performance_ocr_observations,
            "resource_workload_scope": "The performance inputs are the fixed 1/10/50-page text workloads; recorded actual OCR page counts determine whether OCR ran. OCR memory observations are separately available in quality.resource_observation.",
            "timed_business_success": sum(success(r) for r in measured),
            "timed_within_300_seconds": sum(target(r) for r in measured),
            "fifty_page_business_success": sum(success(r) for r in fifty),
            "fifty_page_within_300_seconds": sum(target(r) for r in fifty),
            "fifty_page_planned": 8,
            "unaffected_1_and_10_page_planned": 16,
            "unaffected_1_and_10_page_within_300_seconds": sum(
                target(row) for row in unaffected
            ),
            "unaffected_1_and_10_page_gate": unaffected_1_and_10_page_gate,
            "protocol_complete": perf_complete if perf_records else None,
            "missing_slots": [list(k) for k in sorted(planned_perf - set(perf_groups))],
            "duplicate_slots": duplicate_perf,
            "groups": perf_summary.get("groups"),
            "resource_complete": resource_complete if measured else None,
            "observed_window_peaks_bytes": peaks,
            "observed_window_peaks_mib": {
                k: v / 1048576 if v is not None else None for k, v in peaks.items()
            },
            "limits_bytes": LIMITS,
            "memory_budget_pass": memory_gate,
            "memory_scope": "Maximum observed per-run window values; simultaneous sum is an actual sample sum, not sum of component maxima. Shared PostgreSQL container RSS can double-count shared pages.",
        },
        "overall_observed_app_peak": overall_observed_app_peak,
        "overall_observed_app_peak_scope": "Largest actual sampled application-window observation across quality and all performance runs, including separately identified warmups. This is a descriptive observation with its own window completeness, not a replacement for any missing per-run measurement and not a new acceptance gate.",
        "correction_ui": {
            "timed_observed": len(timed_ui),
            "below_500_ms": ui_good,
            "planned_timed": 24,
            "protocol_complete": ui_complete if ui_attempts else None,
            "by_group": ui_summary.get("by_group"),
            "missing_slots": sorted(planned_ui - set(ui_ids)),
            "duplicate_slots": [k for k, v in ui_ids.items() if v != 1],
            "browser_render_success": ui_summary.get("business_render_acceptance"),
            "browser_resource_budget": ui_summary.get("resource_budget_acceptance"),
        },
        "technical": {
            "fault_cases_passed": sum(
                r.get("passed") is True for r in fault.get("cases", [])
            ),
            "fault_receipt_declared_pass": fault.get("passed"),
            "fault_receipt_pass": fault_gate,
            "restart_receipt_declared_pass": restart.get("passed"),
            "restart_receipt_pass": restart_gate,
            "restart_http_checks": len(restart.get("checks", [])),
            "restart_interrupted_records": len(restart.get("interrupted_imports", [])),
            "junit_receipts": junit,
            "junit_counts_are_selected_execution_receipts_not_unique_test_ids": True,
            "gate": technical_gate,
        },
        "user_authorized_gates": {
            "fifty_page_6_of_8_within_300_seconds": fifty_gate,
            "unaffected_1_and_10_page_gate": unaffected_1_and_10_page_gate,
            "ui_20_of_24_below_500_ms": ui_gate,
            "import_memory_budget": memory_gate,
            "complete_protocol": protocol_gate,
            "technical": technical_gate,
        },
        "original_strict_gates": {
            "import_24_of_24_within_300_seconds": strict_import,
            "ui_24_of_24_below_500_ms": strict_ui,
            "import_memory_budget": memory_gate,
            "warmups_are_reported_separately": True,
        },
        "acceptance_passed": all_known(
            [
                fifty_gate,
                unaffected_1_and_10_page_gate,
                ui_gate,
                memory_gate,
                protocol_gate,
                technical_gate,
                None if missing else True,
                not errors,
            ]
        ),
        "original_strict_acceptance_passed": all_known(
            [
                strict_import,
                strict_ui,
                memory_gate,
                protocol_gate,
                technical_gate,
                None if missing else True,
                not errors,
            ]
        ),
        "cloud": {
            "actual_http_attempts": calls if reports or perf_records else None,
            "requested_models": sorted(requested),
            "response_models": sorted(response_models),
            "response_usage_records": len(usages),
            "tokens": token_totals,
            "fee": None,
            "fee_reason": "provider fee not returned; no pricing estimate invented",
        },
        "missing_artifacts": missing,
        "aggregation_errors": errors,
        "input_artifacts": list(sources.values()),
        "aggregation_script_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "output": str(output),
                "acceptance_passed": result["acceptance_passed"],
                "fifty_page_success": result["import_performance"][
                    "fifty_page_business_success"
                ],
                "fifty_page_target": result["import_performance"][
                    "fifty_page_within_300_seconds"
                ],
                "ui_below_500_ms": ui_good,
                "application_peak_bytes": peaks["app_working_set_bytes"],
                "missing_artifacts": len(missing),
                "aggregation_errors": len(errors),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
