import json, os, subprocess, sys
from pathlib import Path
from dotenv import dotenv_values
from sqlalchemy.engine import make_url
repo=Path.cwd(); run=repo/'.cache/t160-retest-20261003'; source=run/'source-final'
sys.path.insert(0,str(source))
from backend.app.core.config import get_settings
settings=get_settings(); record=json.loads((run/'isolation.json').read_text())
env=os.environ.copy(); env.update({k:v for k,v in dotenv_values(repo/'.env').items() if v is not None})
env['DATABASE_URL']=make_url(str(settings.database_url)).set(database=record['database']).render_as_string(hide_password=False)
env['REDIS_URL']=f"redis://127.0.0.1:{record['redis_port']}/0"; env['STORAGE_ROOT']=str(run/'business-files'); env['PYTHONIOENCODING']='utf-8'; env['VISION_MODEL']=''; env['PYTHONPATH']=str(source)
if (run/'restart-receipt.json').exists() or (run/'restart-acceptance.log').exists():
    raise ValueError("Fresh restart output required; never overwrite an executed check.")
import socket
with socket.socket() as probe:
    probe.bind(("127.0.0.1",17970))
with (run/'restart-acceptance.log').open('xb') as log:
    child=subprocess.run([sys.executable,str(run/'restart-acceptance.py')],env=env,cwd=source,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({'exit_code':child.returncode,'log':str(run/'restart-acceptance.log')}),flush=True)
raise SystemExit(child.returncode)
