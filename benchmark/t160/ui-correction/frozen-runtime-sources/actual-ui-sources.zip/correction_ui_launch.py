"""Launch only committed snapshot UI with isolated resources. No paid model calls."""
import argparse,json,os,subprocess,sys
from pathlib import Path
from dotenv import dotenv_values
from sqlalchemy.engine import make_url
repo=Path(__file__).resolve().parents[2]
run=Path(__file__).resolve().parent
source=run/"source-head"
parser=argparse.ArgumentParser()
parser.add_argument("--fixtures",type=Path,required=True)
parser.add_argument("--workload",choices=["text","figure","cross"],required=True)
parser.add_argument("--temperature",choices=["cold","warm"],required=True)
parser.add_argument("--repeat",type=int,default=1)
parser.add_argument("--port",type=int,default=7871)
parser.add_argument("--output",type=Path,required=True)
args=parser.parse_args()
isolation=json.loads((run/"isolation.json").read_text(encoding="utf-8"))
sys.path.insert(0,str(source))
from backend.app.core.config import get_settings
settings=get_settings()
assert isolation["database"].startswith("eduagent_e2_acceptance_")
env=os.environ.copy();env.update({k:v for k,v in dotenv_values(repo/".env").items() if v is not None})
env.update(DATABASE_URL=make_url(str(settings.database_url)).set(database=isolation["database"]).render_as_string(hide_password=False),
    REDIS_URL=f"redis://127.0.0.1:{isolation['redis_port']}/0",
    STORAGE_ROOT=str(run/"business-files"),PYTHONPATH=str(source),PYTHONIOENCODING="utf-8",VISION_MODEL="")
out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
cmd=[sys.executable,str(run/"correction_ui_server.py"),"--fixtures",str(args.fixtures.resolve()),"--workload",args.workload,"--temperature",args.temperature,"--repeat",str(args.repeat),"--port",str(args.port),"--output",str(out)]
with (out/"server.log").open("xb") as log:
    result=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({"exit_code":result.returncode,"log":str(out/"server.log")}),flush=True)
raise SystemExit(result.returncode)
